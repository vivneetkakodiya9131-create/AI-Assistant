# Add project specific ProGuard rules here.
-keep class com.aiassistant.app.** { *; }
