package com.aiassistant.app.repository

import android.content.Context
import android.content.SharedPreferences
import com.aiassistant.app.model.AppSettings
import com.aiassistant.app.model.CommandHistoryItem
import org.json.JSONArray
import org.json.JSONObject

class AssistantRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "ai_assistant_prefs"
        private const val KEY_HISTORY = "command_history_json"
        private const val KEY_FIRST_LAUNCH = "is_first_launch"
        private const val KEY_VOICE_RESPONSE = "voice_response_enabled"
        private const val KEY_LANGUAGE = "app_language"
        private const val KEY_AI_CONFIGURED = "ai_provider_configured"
        private const val KEY_AI_KEY = "ai_api_key"
        private const val KEY_AI_ENDPOINT = "ai_custom_endpoint"
    }

    fun isFirstLaunch(): Boolean {
        return prefs.getBoolean(KEY_FIRST_LAUNCH, true)
    }

    fun setFirstLaunchCompleted() {
        prefs.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply()
    }

    fun getHistory(): List<CommandHistoryItem> {
        val jsonString = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        val list = mutableListOf<CommandHistoryItem>()
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    CommandHistoryItem(
                        id = obj.optString("id", System.currentTimeMillis().toString()),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        userCommand = obj.optString("userCommand", ""),
                        assistantResponse = obj.optString("assistantResponse", ""),
                        status = obj.optString("status", "SUCCESS"),
                        success = obj.optBoolean("success", true)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun addHistoryItem(item: CommandHistoryItem) {
        val current = getHistory().toMutableList()
        current.add(0, item) // Add latest at top
        saveHistoryList(current)
    }

    fun deleteHistoryItem(id: String) {
        val current = getHistory().toMutableList()
        current.removeAll { it.id == id }
        saveHistoryList(current)
    }

    fun clearHistory() {
        prefs.edit().remove(KEY_HISTORY).apply()
    }

    private fun saveHistoryList(list: List<CommandHistoryItem>) {
        try {
            val jsonArray = JSONArray()
            // Cap at 100 recent entries to keep storage compact
            list.take(100).forEach { item ->
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("timestamp", item.timestamp)
                    put("userCommand", item.userCommand)
                    put("assistantResponse", item.assistantResponse)
                    put("status", item.status)
                    put("success", item.success)
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString(KEY_HISTORY, jsonArray.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getSettings(): AppSettings {
        return AppSettings(
            isVoiceResponseEnabled = prefs.getBoolean(KEY_VOICE_RESPONSE, true),
            language = prefs.getString(KEY_LANGUAGE, "Hindi") ?: "Hindi",
            isAiProviderConfigured = prefs.getBoolean(KEY_AI_CONFIGURED, false),
            aiApiKey = prefs.getString(KEY_AI_KEY, "") ?: "",
            customAiEndpoint = prefs.getString(KEY_AI_ENDPOINT, "") ?: ""
        )
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putBoolean(KEY_VOICE_RESPONSE, settings.isVoiceResponseEnabled)
            .putString(KEY_LANGUAGE, settings.language)
            .putBoolean(KEY_AI_CONFIGURED, settings.isAiProviderConfigured)
            .putString(KEY_AI_KEY, settings.aiApiKey)
            .putString(KEY_AI_ENDPOINT, settings.customAiEndpoint)
            .apply()
    }
}
