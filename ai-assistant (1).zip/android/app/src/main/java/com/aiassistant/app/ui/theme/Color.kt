package com.aiassistant.app.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceBorder = Color(0xFF1E293B)
val DarkSurfaceElevated = Color(0xFF1E2A42)

val AccentCyan = Color(0xFF0284C7)
val AccentCyanLight = Color(0xFF38BDF8)
val AccentPurple = Color(0xFF6366F1)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val StatusSuccess = Color(0xFF10B981)
val StatusWarning = Color(0xFFF59E0B)
val StatusError = Color(0xFFEF4444)
