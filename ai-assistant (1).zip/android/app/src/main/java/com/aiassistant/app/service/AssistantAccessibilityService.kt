package com.aiassistant.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AssistantAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "AssistantAccessService"

        @Volatile
        var instance: AssistantAccessibilityService? = null
            private set

        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected

        fun isRunning(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceConnected.value = true
        Log.d(TAG, "AssistantAccessibilityService Connected successfully.")

        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_DEFAULT or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            notificationTimeout = 100
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Accessibility events monitored if contextual UI tracking is active
    }

    override fun onInterrupt() {
        Log.w(TAG, "AssistantAccessibilityService Interrupted.")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isServiceConnected.value = false
        Log.d(TAG, "AssistantAccessibilityService Destroyed.")
    }

    // --- Core Navigation Operations ---

    fun performGoHome(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun performGoBack(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun performOpenRecents(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    fun performOpenNotifications(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    // --- Screen Interaction Operations ---

    /**
     * Finds and clicks a visible UI element by its text (case-insensitive substring or exact match).
     * If the matched node itself is not clickable, traverses up to its nearest clickable parent.
     */
    fun clickElementByText(textQuery: String, exactMatch: Boolean = false): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val cleanQuery = textQuery.trim().lowercase()

        val matchingNodes = rootNode.findAccessibilityNodeInfosByText(cleanQuery)
        if (matchingNodes.isNullOrEmpty()) {
            // Fallback: full tree depth traversal for partial Hindi/English text matches
            val customMatched = findNodeMatchingPredicate(rootNode) { node ->
                val nodeText = node.text?.toString()?.lowercase() ?: ""
                val nodeDesc = node.contentDescription?.toString()?.lowercase() ?: ""
                if (exactMatch) {
                    nodeText == cleanQuery || nodeDesc == cleanQuery
                } else {
                    nodeText.contains(cleanQuery) || nodeDesc.contains(cleanQuery)
                }
            }
            if (customMatched != null) {
                return clickNodeOrParent(customMatched)
            }
            return false
        }

        for (node in matchingNodes) {
            val nodeText = node.text?.toString()?.lowercase() ?: ""
            val nodeDesc = node.contentDescription?.toString()?.lowercase() ?: ""
            val isGoodMatch = if (exactMatch) {
                nodeText == cleanQuery || nodeDesc == cleanQuery
            } else {
                nodeText.contains(cleanQuery) || nodeDesc.contains(cleanQuery)
            }
            if (isGoodMatch) {
                if (clickNodeOrParent(node)) {
                    return true
                }
            }
        }

        // If exact check didn't click, try clicking the first match's clickable hierarchy
        return clickNodeOrParent(matchingNodes[0])
    }

    /**
     * Clicks a UI element by its resource-id or view-id (e.g., "com.whatsapp:id/send_button")
     */
    fun clickElementById(viewId: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val nodes = rootNode.findAccessibilityNodeInfosByViewId(viewId)
        if (!nodes.isNullOrEmpty()) {
            return clickNodeOrParent(nodes[0])
        }
        return false
    }

    /**
     * Sets text into the currently focused editable field or an element matching targetHint.
     */
    fun typeTextIntoField(targetHint: String?, textToType: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false

        var targetNode: AccessibilityNodeInfo? = null

        // 1. Check if an editable node is currently focused
        val focusedNode = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focusedNode != null && (focusedNode.isEditable || focusedNode.className?.contains("EditText", true) == true)) {
            targetNode = focusedNode
        }

        // 2. If no focused node or targetHint provided, look for matching hint/content description
        if (targetNode == null && !targetHint.isNullOrBlank()) {
            val hintMatches = rootNode.findAccessibilityNodeInfosByText(targetHint)
            targetNode = hintMatches?.firstOrNull { it.isEditable || it.className?.contains("EditText", true) == true }
        }

        // 3. Fallback: find any visible editable field on screen
        if (targetNode == null) {
            targetNode = findNodeMatchingPredicate(rootNode) { it.isEditable }
        }

        targetNode?.let { node ->
            val arguments = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    textToType
                )
            }
            val result = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            if (!result) {
                // Try focus first, then set text
                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            }
            return result
        }

        return false
    }

    /**
     * Scrolls the current active screen either forward (down) or backward (up).
     */
    fun scrollScreen(forward: Boolean): Boolean {
        val rootNode = rootInActiveWindow ?: return false

        val scrollableNode = findNodeMatchingPredicate(rootNode) { it.isScrollable }
        return if (scrollableNode != null) {
            val action = if (forward) {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            }
            scrollableNode.performAction(action)
        } else {
            false
        }
    }

    /**
     * Extracts readable text strings from all visible UI nodes on the active screen.
     */
    fun extractCurrentScreenTexts(): List<String> {
        val rootNode = rootInActiveWindow ?: return emptyList()
        val textList = mutableListOf<String>()

        fun traverse(node: AccessibilityNodeInfo?) {
            if (node == null) return
            val text = node.text?.toString()
            val desc = node.contentDescription?.toString()
            if (!text.isNullOrBlank()) textList.add(text.trim())
            if (!desc.isNullOrBlank() && desc != text) textList.add(desc.trim())

            for (i in 0 until node.childCount) {
                traverse(node.getChild(i))
            }
        }

        traverse(rootNode)
        return textList
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo?): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        // If not explicitly marked clickable, try firing ACTION_CLICK on the node anyway
        return node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    private fun findNodeMatchingPredicate(
        root: AccessibilityNodeInfo?,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (root == null) return null
        if (predicate(root)) return root

        for (i in 0 until root.childCount) {
            val child = root.getChild(i)
            val match = findNodeMatchingPredicate(child, predicate)
            if (match != null) return match
        }
        return null
    }
}
