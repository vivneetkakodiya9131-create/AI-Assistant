package com.aiassistant.app.model

enum class AssistantStatus {
    READY,
    LISTENING,
    PROCESSING,
    EXECUTING,
    SPEAKING,
    ERROR
}

enum class ActionType {
    OPEN_APP,
    GO_HOME,
    GO_BACK,
    OPEN_RECENTS,
    SCROLL_UP,
    SCROLL_DOWN,
    CLICK_TEXT,
    TYPE_TEXT,
    READ_SCREEN,
    OPEN_SETTINGS,
    WEB_SEARCH,
    VOLUME_CONTROL,
    SET_ALARM,
    SEND_MESSAGE,
    UNKNOWN
}

enum class ScrollDirection {
    FORWARD,
    BACKWARD
}

enum class VolumeAction {
    INCREASE,
    DECREASE,
    MUTE
}

sealed class AssistantIntent(val rawQuery: String, val requiresConfirmation: Boolean = false) {
    data class OpenApp(val appName: String, val packageName: String?, val query: String) :
        AssistantIntent(query)

    data class GoHome(val query: String) : AssistantIntent(query)

    data class GoBack(val query: String) : AssistantIntent(query)

    data class OpenRecents(val query: String) : AssistantIntent(query)

    data class ScrollUp(val query: String) : AssistantIntent(query)

    data class ScrollDown(val query: String) : AssistantIntent(query)

    data class ClickText(val targetText: String, val query: String) : AssistantIntent(query)

    data class TypeText(val text: String, val targetHint: String? = null, val query: String) : AssistantIntent(query)

    data class ReadScreen(val query: String) : AssistantIntent(query)

    data class OpenSettings(val query: String) : AssistantIntent(query)

    data class WebSearch(val searchQuery: String, val engine: String, val query: String) :
        AssistantIntent(query)

    data class Volume(val action: VolumeAction, val query: String) :
        AssistantIntent(query)

    data class Alarm(val timeString: String, val hour: Int, val minute: Int, val label: String, val query: String) :
        AssistantIntent(query)

    data class SendMessage(
        val recipient: String,
        val messageText: String,
        val platform: String,
        val query: String
    ) : AssistantIntent(query, requiresConfirmation = true)

    data class MultiStep(val steps: List<AssistantIntent>, val query: String) :
        AssistantIntent(query)

    data class Unknown(val message: String, val query: String) :
        AssistantIntent(query)
}

data class PlannedStep(
    val stepNumber: Int,
    val description: String,
    val actionType: ActionType,
    val execute: suspend () -> ExecutionResult
)

data class ExecutionResult(
    val success: Boolean,
    val hindiResponse: String,
    val englishDetail: String
)

data class CommandHistoryItem(
    val id: String,
    val timestamp: Long,
    val userCommand: String,
    val assistantResponse: String,
    val status: String,
    val success: Boolean
)

data class AppSettings(
    val isVoiceResponseEnabled: Boolean = true,
    val language: String = "Hindi", // "Hindi", "English", "Auto"
    val isAiProviderConfigured: Boolean = false,
    val aiApiKey: String = "",
    val customAiEndpoint: String = ""
)
