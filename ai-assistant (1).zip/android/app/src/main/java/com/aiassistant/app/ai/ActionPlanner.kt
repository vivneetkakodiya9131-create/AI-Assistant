package com.aiassistant.app.ai

import com.aiassistant.app.model.ActionType
import com.aiassistant.app.model.AssistantIntent
import com.aiassistant.app.model.PlannedStep
import com.aiassistant.app.model.ScrollDirection

class ActionPlanner(
    private val executor: AndroidActionExecutor
) {

    fun plan(intent: AssistantIntent): List<PlannedStep> {
        val steps = mutableListOf<PlannedStep>()

        when (intent) {
            is AssistantIntent.OpenApp -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "${intent.appName} ऐप लॉन्च करें",
                        actionType = ActionType.OPEN_APP,
                        execute = { executor.launchApp(intent.appName, intent.packageName) }
                    )
                )
            }

            is AssistantIntent.GoHome -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "होम स्क्रीन पर जाएं",
                        actionType = ActionType.GO_HOME,
                        execute = { executor.performNavigation(ActionType.GO_HOME) }
                    )
                )
            }

            is AssistantIntent.GoBack -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "पीछे जाएं",
                        actionType = ActionType.GO_BACK,
                        execute = { executor.performNavigation(ActionType.GO_BACK) }
                    )
                )
            }

            is AssistantIntent.OpenRecents -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "हाल ही में खोले गए ऐप्स दिखाएं",
                        actionType = ActionType.OPEN_RECENTS,
                        execute = { executor.performNavigation(ActionType.OPEN_RECENTS) }
                    )
                )
            }

            is AssistantIntent.OpenSettings -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "सिस्टम सेटिंग्स खोलें",
                        actionType = ActionType.OPEN_SETTINGS,
                        execute = { executor.openSystemSettings() }
                    )
                )
            }

            is AssistantIntent.ScrollDown -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "स्क्रीन नीचे स्क्रॉल करें",
                        actionType = ActionType.SCROLL_DOWN,
                        execute = { executor.scrollScreen(ScrollDirection.FORWARD) }
                    )
                )
            }

            is AssistantIntent.ScrollUp -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "स्क्रीन ऊपर स्क्रॉल करें",
                        actionType = ActionType.SCROLL_UP,
                        execute = { executor.scrollScreen(ScrollDirection.BACKWARD) }
                    )
                )
            }

            is AssistantIntent.ClickText -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "स्क्रीन पर \"${intent.targetText}\" पर क्लिक करें",
                        actionType = ActionType.CLICK_TEXT,
                        execute = { executor.clickScreenElement(intent.targetText, null) }
                    )
                )
            }

            is AssistantIntent.TypeText -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "फ़ील्ड में \"${intent.text}\" टाइप करें",
                        actionType = ActionType.TYPE_TEXT,
                        execute = { executor.typeText(intent.targetHint, intent.text) }
                    )
                )
            }

            is AssistantIntent.ReadScreen -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "सक्रिय स्क्रीन का टेक्स्ट पढ़ें",
                        actionType = ActionType.READ_SCREEN,
                        execute = { executor.readActiveScreen() }
                    )
                )
            }

            is AssistantIntent.WebSearch -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "${intent.engine} पर \"${intent.searchQuery}\" खोजें",
                        actionType = ActionType.WEB_SEARCH,
                        execute = { executor.performWebSearch(intent.searchQuery, intent.engine) }
                    )
                )
            }

            is AssistantIntent.Volume -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "वॉल्यूम बदलें",
                        actionType = ActionType.VOLUME_CONTROL,
                        execute = { executor.adjustVolume(intent.action) }
                    )
                )
            }

            is AssistantIntent.Alarm -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "${intent.timeString} का अलार्म सेट करें",
                        actionType = ActionType.SET_ALARM,
                        execute = { executor.setAlarm(intent.hour, intent.minute, intent.label) }
                    )
                )
            }

            is AssistantIntent.SendMessage -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "${intent.platform} खोलें और ${intent.recipient} को संदेश भेजें",
                        actionType = ActionType.SEND_MESSAGE,
                        execute = { executor.prepareSendMessage(intent.recipient, intent.messageText) }
                    )
                )
            }

            is AssistantIntent.MultiStep -> {
                var stepCounter = 1
                for (subIntent in intent.steps) {
                    val subSteps = plan(subIntent)
                    for (step in subSteps) {
                        steps.add(step.copy(stepNumber = stepCounter++))
                    }
                }
            }

            is AssistantIntent.Unknown -> {
                steps.add(
                    PlannedStep(
                        stepNumber = 1,
                        description = "असिस्टेंट संदेश",
                        actionType = ActionType.UNKNOWN,
                        execute = { executor.handleUnknown(intent.message) }
                    )
                )
            }
        }

        return steps
    }
}
