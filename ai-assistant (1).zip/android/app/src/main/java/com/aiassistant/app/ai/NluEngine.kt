package com.aiassistant.app.ai

import com.aiassistant.app.model.AssistantIntent
import com.aiassistant.app.model.VolumeAction
import java.util.regex.Pattern

object NluEngine {

    private val APP_ALIASES = mapOf(
        "youtube" to "com.google.android.youtube",
        "यूट्यूब" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "व्हाट्सएप" to "com.whatsapp",
        "chrome" to "com.android.chrome",
        "क्रोम" to "com.android.chrome",
        "google maps" to "com.google.android.apps.maps",
        "maps" to "com.google.android.apps.maps",
        "मैप्स" to "com.google.android.apps.maps",
        "गूगल मैप्स" to "com.google.android.apps.maps",
        "camera" to "com.google.android.GoogleCamera",
        "कैमरा" to "com.google.android.GoogleCamera",
        "settings" to "com.android.settings",
        "सेटिंग्स" to "com.android.settings",
        "सेटिंग" to "com.android.settings",
        "instagram" to "com.instagram.android",
        "इंस्टाग्राम" to "com.instagram.android",
        "telegram" to "org.telegram.messenger",
        "टेलीग्राम" to "org.telegram.messenger",
        "play store" to "com.android.vending",
        "प्ले स्टोर" to "com.android.vending",
        "gmail" to "com.google.android.gm",
        "जीमेल" to "com.google.android.gm",
        "clock" to "com.google.android.deskclock",
        "घड़ी" to "com.google.android.deskclock",
        "calculator" to "com.google.android.calculator",
        "कैलकुलेटर" to "com.google.android.calculator",
        "facebook" to "com.facebook.katana",
        "फेसबुक" to "com.facebook.katana",
        "spotify" to "com.spotify.music"
    )

    fun parseCommand(rawText: String, screenContext: List<String> = emptyList()): AssistantIntent {
        val text = rawText.trim()
        val lower = text.lowercase()

        // 1. Compound Multi-Step Commands: e.g. "Chrome kholo aur Google search karo"
        if (lower.contains("aur") || lower.contains("and") || lower.contains("फिर")) {
            val parts = lower.split(Regex("\\s+(?:aur|and|फिर|then)\\s+"))
            if (parts.size >= 2) {
                val subIntents = parts.map { parseCommand(it, screenContext) }
                if (subIntents.all { it !is AssistantIntent.Unknown }) {
                    return AssistantIntent.MultiStep(steps = subIntents, query = text)
                }
            }
        }

        // 2. Navigation Commands (Home, Back, Recents)
        if (matchesAny(lower, "home par jao", "home jao", "home", "go home", "ghar jao", "होम पर जाओ", "होम जाओ", "होम")) {
            return AssistantIntent.GoHome(text)
        }
        if (matchesAny(lower, "back karo", "back jao", "peeche jao", "wapas jao", "go back", "back", "बैक करो", "बैक जाओ", "पीछे जाओ", "वापस जाओ")) {
            return AssistantIntent.GoBack(text)
        }
        if (matchesAny(lower, "recent apps kholo", "recent apps dikhao", "recent apps", "recent kholo", "recents", "टास्क दिखाओ", "रीसेंट ऐप्स", "रीसेंट ऐप्स खोलो")) {
            return AssistantIntent.OpenRecents(text)
        }

        // 3. Settings Commands
        if (matchesAny(lower, "settings kholo", "setting kholo", "open settings", "सेटिंग्स खोलो", "सेटिंग खोलो")) {
            return AssistantIntent.OpenSettings(text)
        }

        // 4. Scrolling Commands
        if (matchesAny(lower, "neeche scroll karo", "niche scroll karo", "scroll down", "niche jao", "neeche jao", "नीचे स्क्रॉल करो")) {
            return AssistantIntent.ScrollDown(text)
        }
        if (matchesAny(lower, "upar scroll karo", "scroll up", "upar jao", "ऊपर स्क्रॉल करो")) {
            return AssistantIntent.ScrollUp(text)
        }

        // 5. Read Screen Content
        if (matchesAny(lower, "screen read karo", "screen padho", "read screen", "screen par kya hai", "स्क्रीन पढ़ो", "स्क्रीन रीड करो")) {
            return AssistantIntent.ReadScreen(text)
        }

        // 6. Typing into active field: e.g. "Yahan mera naam type karo", "Type Hello World"
        val typeRegex = Pattern.compile(
            "(?:yahan|here)?\\s*(.+?)\\s*(?:type\\s*karo|likho|टाइप\\s*करो|लिखो)",
            Pattern.CASE_INSENSITIVE
        )
        val typeMatcher = typeRegex.matcher(lower)
        if (typeMatcher.find()) {
            val contentToType = typeMatcher.group(1)?.trim() ?: ""
            if (contentToType.isNotBlank() && !matchesAny(contentToType, "kholo", "search", "scroll")) {
                val cleanText = if (contentToType.contains("mera naam")) "User Name" else contentToType
                return AssistantIntent.TypeText(text = cleanText, targetHint = null, query = text)
            }
        }

        // 7. Click UI text / button on screen: e.g. "Is text par click karo", "Search par click karo", "Submit button dabao"
        val clickRegex = Pattern.compile(
            "(?:screen\\s+par\\s+jo\\s+)?(.+?)(?:\\s+button|\\s+ko|\\s+pe|\\s+par)?\\s*(?:use\\s+)?(?:dabao|click\\s*karo|tap\\s*karo|press\\s*karo|दबाओ|क्लिक\\s*करो)",
            Pattern.CASE_INSENSITIVE
        )
        val clickMatcher = clickRegex.matcher(lower)
        if (clickMatcher.find()) {
            val rawTarget = clickMatcher.group(1)?.replace("button", "")?.replace("is text", "")?.replace("text", "")?.trim() ?: ""
            val target = if (rawTarget.isBlank()) "Search" else rawTarget
            if (!matchesAny(target, "volume", "awaz", "sound")) {
                return AssistantIntent.ClickText(targetText = target, query = text)
            }
        }

        // 8. Volume Controls
        if (matchesAny(lower, "volume kam karo", "awaz kam karo", "volume ghatao", "sound kam karo", "आवाज़ कम करो", "वॉल्यूम कम करो")) {
            return AssistantIntent.Volume(VolumeAction.DECREASE, text)
        }
        if (matchesAny(lower, "volume badhao", "awaz badhao", "sound badhao", "volume badha do", "आवाज़ बढ़ाओ", "वॉल्यूम बढ़ाओ")) {
            return AssistantIntent.Volume(VolumeAction.INCREASE, text)
        }
        if (matchesAny(lower, "mute karo", "silent karo", "awaz band karo", "आवाज़ बंद करो")) {
            return AssistantIntent.Volume(VolumeAction.MUTE, text)
        }

        // 9. Alarm Scheduling
        if (matchesAny(lower, "alarm lagao", "alarm set karo", "अलार्म लगाओ", "अलार्म सेट करो")) {
            val (hour, minute) = extractTimeFromText(lower)
            return AssistantIntent.Alarm(
                timeString = "$hour:${if (minute < 10) "0$minute" else "$minute"}",
                hour = hour,
                minute = minute,
                label = "AI Assistant Alarm",
                query = text
            )
        }

        // 10. Web / YouTube Search
        val searchRegex = Pattern.compile(
            "(?:google|youtube|chrome)?\\s*(?:par|me|mein)?\\s*(.+?)\\s*(?:search\\s*karo|khojo|dhundo|dhoondo|सर्च\\s*करो|ढूंढो|खोजो)",
            Pattern.CASE_INSENSITIVE
        )
        val searchMatcher = searchRegex.matcher(lower)
        if (searchMatcher.find()) {
            val searchQuery = searchMatcher.group(1)?.trim() ?: ""
            val engine = if (lower.contains("youtube") || lower.contains("यूट्यूब")) "youtube" else "google"
            if (searchQuery.isNotBlank()) {
                return AssistantIntent.WebSearch(searchQuery = searchQuery, engine = engine, query = text)
            }
        }

        // 11. WhatsApp / Messaging Actions
        val messageRegex = Pattern.compile(
            "(?:whatsapp|संदेश)?\\s*(?:mein|me)?\\s*(.+?)\\s*ko\\s*(?:message|sandesh)?\\s*(?:bhejo|karo)",
            Pattern.CASE_INSENSITIVE
        )
        val msgMatcher = messageRegex.matcher(lower)
        if (msgMatcher.find()) {
            val recipient = msgMatcher.group(1)?.trim() ?: "Contact"
            return AssistantIntent.SendMessage(
                recipient = recipient,
                messageText = "नमस्ते, AI Assistant से भेजा गया संदेश",
                platform = "WhatsApp",
                query = text
            )
        }

        // 12. App Launch Commands: e.g. "WhatsApp kholo", "YouTube kholo", "Google Maps kholo", "Camera kholo"
        val openAppRegex = Pattern.compile(
            "(.+?)\\s*(?:kholo|open\\s*karo|chalao|start\\s*karo|launch\\s*karo|खोलो|शुरू\\s*करो|चलाओ)",
            Pattern.CASE_INSENSITIVE
        )
        val openMatcher = openAppRegex.matcher(lower)
        if (openMatcher.find()) {
            val requestedApp = openMatcher.group(1)?.trim() ?: ""
            val normalizedApp = requestedApp.replace(Regex("^(app|application|meri|mera)\\s+"), "").trim()
            val packageName = APP_ALIASES[normalizedApp]

            return AssistantIntent.OpenApp(
                appName = capitalize(normalizedApp),
                packageName = packageName,
                query = text
            )
        }

        // Direct alias match check
        for ((alias, pkg) in APP_ALIASES) {
            if (lower.contains(alias)) {
                return AssistantIntent.OpenApp(
                    appName = capitalize(alias),
                    packageName = pkg,
                    query = text
                )
            }
        }

        // 13. Fallback for unknown / unsupported commands
        return AssistantIntent.Unknown(
            message = "माफ़ कीजिए, यह कमांड समझ नहीं आई। आप बोल सकते हैं \"WhatsApp kholo\", \"YouTube kholo\", \"Home par jao\", \"Neeche scroll karo\" आदि।",
            query = text
        )
    }

    private fun matchesAny(input: String, vararg phrases: String): Boolean {
        return phrases.any { input.contains(it) || input.equals(it, ignoreCase = true) }
    }

    private fun extractTimeFromText(text: String): Pair<Int, Int> {
        val digitMatcher = Pattern.compile("(\\d{1,2})(?:\\s*(?:baje|बजे|am|pm|:\\d{2}))?").matcher(text)
        var hour = 7
        var minute = 0
        if (digitMatcher.find()) {
            hour = digitMatcher.group(1)?.toIntOrNull() ?: 7
            if (text.contains("shaam") || text.contains("raat") || text.contains("pm")) {
                if (hour < 12) hour += 12
            }
        }
        return Pair(hour, minute)
    }

    private fun capitalize(str: String): String {
        return str.split(" ").joinToString(" ") { s ->
            s.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }
    }
}
