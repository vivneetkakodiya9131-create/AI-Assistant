package com.aiassistant.app.safety

import com.aiassistant.app.model.AssistantIntent

object SafetyManager {

    private val SENSITIVE_KEYWORDS = listOf(
        "pay", "payment", "upi", "paisa", "paise", "transfer", "rupaye", "kharido", "purchase",
        "delete", "hatao", "format", "mitao", "clean", "uninstall",
        "call", "phone lagao", "call karo", "dial",
        "factory reset", "lock phone", "security", "password", "bhejo", "send"
    )

    fun isActionSensitive(intent: AssistantIntent): Boolean {
        if (intent.requiresConfirmation) return true
        if (intent is AssistantIntent.SendMessage) return true

        val queryLower = intent.rawQuery.lowercase()
        return SENSITIVE_KEYWORDS.any { queryLower.contains(it) }
    }

    /**
     * Strict requirement 10:
     * "Main ye action karne wala hoon. Kya main continue karun?"
     * Buttons: Cancel, Confirm
     */
    fun getConfirmationPrompt(intent: AssistantIntent): String {
        return when (intent) {
            is AssistantIntent.SendMessage -> {
                "Main ${intent.recipient} ko message bhejne wala hoon. Kya main continue karun?"
            }
            else -> {
                "Main ye action karne wala hoon. Kya main continue karun?"
            }
        }
    }
}
