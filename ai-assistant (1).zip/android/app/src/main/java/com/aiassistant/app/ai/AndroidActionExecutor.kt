package com.aiassistant.app.ai

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.util.Log
import com.aiassistant.app.model.ActionType
import com.aiassistant.app.model.ExecutionResult
import com.aiassistant.app.model.ScrollDirection
import com.aiassistant.app.model.VolumeAction
import com.aiassistant.app.service.AssistantAccessibilityService

class AndroidActionExecutor(
    private val context: Context
) {

    companion object {
        private const val TAG = "AndroidActionExecutor"
    }

    /**
     * Launches an application installed on the device.
     * If not installed, gracefully returns "Ye app aapke phone mein installed nahi hai." without crashing.
     */
    suspend fun launchApp(appName: String, packageHint: String?): ExecutionResult {
        val pm = context.packageManager
        var launchIntent: Intent? = null
        var resolvedPackage = packageHint

        // 1. Try launching direct package if known
        if (!resolvedPackage.isNullOrBlank()) {
            try {
                launchIntent = pm.getLaunchIntentForPackage(resolvedPackage)
            } catch (e: Exception) {
                Log.w(TAG, "Failed getting intent for $resolvedPackage: ${e.message}")
            }
        }

        // 2. Search installed applications matching the app name
        if (launchIntent == null) {
            try {
                val installedPackages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                for (appInfo in installedPackages) {
                    val label = pm.getApplicationLabel(appInfo).toString().lowercase()
                    if (label.contains(appName.lowercase()) || appName.lowercase().contains(label)) {
                        resolvedPackage = appInfo.packageName
                        launchIntent = pm.getLaunchIntentForPackage(appInfo.packageName)
                        if (launchIntent != null) break
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error enumerating installed applications: ${e.message}")
            }
        }

        // 3. Fallback for built-in camera or settings
        if (launchIntent == null) {
            if (appName.contains("camera", ignoreCase = true) || appName.contains("कैमरा", ignoreCase = true)) {
                val camIntent = Intent("android.media.action.IMAGE_CAPTURE").apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (camIntent.resolveActivity(pm) != null) {
                    context.startActivity(camIntent)
                    return ExecutionResult(
                        success = true,
                        hindiResponse = "Bilkul, Camera khol raha hoon.",
                        englishDetail = "Opened Camera."
                    )
                }
            } else if (appName.contains("settings", ignoreCase = true) || appName.contains("सेटिंग", ignoreCase = true)) {
                return openSystemSettings()
            }
        }

        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            return ExecutionResult(
                success = true,
                hindiResponse = "Bilkul, $appName khol raha hoon.",
                englishDetail = "Opened $appName successfully."
            )
        } else {
            // Strict compliance with Requirement 7:
            // "If an application is not installed: Say: 'Ye app aapke phone mein installed nahi hai.'"
            return ExecutionResult(
                success = false,
                hindiResponse = "Ye app aapke phone mein installed nahi hai.",
                englishDetail = "Application $appName is not installed on this device."
            )
        }
    }

    suspend fun openSystemSettings(): ExecutionResult {
        return try {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ExecutionResult(
                success = true,
                hindiResponse = "Bilkul, Settings khol raha hoon.",
                englishDetail = "Opened system settings."
            )
        } catch (e: Exception) {
            ExecutionResult(
                success = false,
                hindiResponse = "Main ye action complete nahi kar paya.",
                englishDetail = "Failed opening settings: ${e.localizedMessage}"
            )
        }
    }

    suspend fun performNavigation(action: ActionType): ExecutionResult {
        val service = AssistantAccessibilityService.instance
        if (service == null) {
            return accessibilityServiceNotRunningResult("नेविगेट")
        }

        val success = when (action) {
            ActionType.GO_HOME -> service.performGoHome()
            ActionType.GO_BACK -> service.performGoBack()
            ActionType.OPEN_RECENTS -> service.performOpenRecents()
            else -> false
        }

        val actionNameHindi = when (action) {
            ActionType.GO_HOME -> "Home screen par aa gaye."
            ActionType.GO_BACK -> "Wapas aa gaye."
            ActionType.OPEN_RECENTS -> "Recent apps khol diye gaye hain."
            else -> "Kriya poori hui."
        }

        return ExecutionResult(
            success = success,
            hindiResponse = if (success) actionNameHindi else "Main ye action complete nahi kar paya.",
            englishDetail = "Navigation $action executed with result: $success"
        )
    }

    suspend fun clickScreenElement(targetText: String, targetId: String?): ExecutionResult {
        val service = AssistantAccessibilityService.instance
        if (service == null) {
            return accessibilityServiceNotRunningResult("स्क्रीन पर क्लिक")
        }

        val success = if (!targetId.isNullOrBlank()) {
            service.clickElementById(targetId)
        } else {
            service.clickElementByText(targetText)
        }

        return if (success) {
            ExecutionResult(
                success = true,
                hindiResponse = "Screen par \"$targetText\" par click kar diya gaya hai.",
                englishDetail = "Clicked screen element matching \"$targetText\"."
            )
        } else {
            ExecutionResult(
                success = false,
                hindiResponse = "Screen par \"$targetText\" button nahi mila. Main ye action complete nahi kar paya.",
                englishDetail = "Element \"$targetText\" could not be found or clicked in the active window."
            )
        }
    }

    suspend fun typeText(targetHint: String?, textToType: String): ExecutionResult {
        val service = AssistantAccessibilityService.instance
        if (service == null) {
            return accessibilityServiceNotRunningResult("टेक्स्ट टाइप")
        }

        val success = service.typeTextIntoField(targetHint, textToType)
        return if (success) {
            ExecutionResult(
                success = true,
                hindiResponse = "\"$textToType\" type kar diya gaya hai.",
                englishDetail = "Typed text successfully into active input."
            )
        } else {
            ExecutionResult(
                success = false,
                hindiResponse = "Type karne ke liye koi input field nahi mili. Main ye action complete nahi kar paya.",
                englishDetail = "No editable field currently available to type."
            )
        }
    }

    suspend fun scrollScreen(direction: ScrollDirection): ExecutionResult {
        val service = AssistantAccessibilityService.instance
        if (service == null) {
            return accessibilityServiceNotRunningResult("स्क्रीन स्क्रॉल")
        }

        val forward = direction == ScrollDirection.FORWARD
        val success = service.scrollScreen(forward)
        val dirText = if (forward) "Neeche" else "Upar"

        return ExecutionResult(
            success = success,
            hindiResponse = if (success) "Screen $dirText scroll kar di gayi hai." else "Main ye action complete nahi kar paya.",
            englishDetail = "Scroll $direction executed: $success"
        )
    }

    suspend fun readActiveScreen(): ExecutionResult {
        val service = AssistantAccessibilityService.instance
        if (service == null) {
            return accessibilityServiceNotRunningResult("स्क्रीन पढ़ना")
        }

        val texts = service.extractCurrentScreenTexts()
        return if (texts.isNotEmpty()) {
            val preview = texts.take(5).joinToString(", ")
            ExecutionResult(
                success = true,
                hindiResponse = "Screen par ye text dikh raha hai: $preview",
                englishDetail = "Read ${texts.size} screen elements."
            )
        } else {
            ExecutionResult(
                success = false,
                hindiResponse = "Screen par padhne yogya koi text nahi mila.",
                englishDetail = "No readable text detected on screen."
            )
        }
    }

    suspend fun performWebSearch(query: String, engine: String): ExecutionResult {
        return try {
            val intent = if (engine.equals("youtube", ignoreCase = true)) {
                Intent(Intent.ACTION_SEARCH).apply {
                    setPackage("com.google.android.youtube")
                    putExtra("query", query)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            } else {
                Intent(Intent.ACTION_WEB_SEARCH).apply {
                    putExtra(SearchManager.QUERY, query)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            }

            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
            } else {
                val browserIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
                ).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(browserIntent)
            }

            ExecutionResult(
                success = true,
                hindiResponse = "$engine par \"$query\" khoja ja raha hai.",
                englishDetail = "Triggered search for \"$query\" on $engine."
            )
        } catch (e: Exception) {
            Log.e(TAG, "Search failed: ${e.message}", e)
            ExecutionResult(
                success = false,
                hindiResponse = "Main ye action complete nahi kar paya.",
                englishDetail = "Search execution failed: ${e.localizedMessage}"
            )
        }
    }

    suspend fun adjustVolume(action: VolumeAction): ExecutionResult {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return ExecutionResult(false, "Main ye action complete nahi kar paya.", "AudioManager unavailable")

        val flag = AudioManager.FLAG_SHOW_UI or AudioManager.FLAG_PLAY_SOUND
        when (action) {
            VolumeAction.INCREASE -> {
                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, flag)
                return ExecutionResult(true, "Volume badha di gayi hai.", "Volume increased")
            }
            VolumeAction.DECREASE -> {
                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, flag)
                return ExecutionResult(true, "Volume kam kar di gayi hai.", "Volume decreased")
            }
            VolumeAction.MUTE -> {
                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, flag)
                return ExecutionResult(true, "Phone silent kar diya gaya hai.", "Audio muted")
            }
        }
    }

    suspend fun setAlarm(hour: Int, minute: Int, label: String): ExecutionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)

            val minFormatted = if (minute < 10) "0$minute" else "$minute"
            ExecutionResult(
                success = true,
                hindiResponse = "$hour:$minFormatted baje ka alarm set kar diya gaya hai.",
                englishDetail = "Alarm scheduled for $hour:$minFormatted."
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error setting alarm: ${e.message}")
            ExecutionResult(
                success = false,
                hindiResponse = "Main ye action complete nahi kar paya.",
                englishDetail = "Setting alarm failed: ${e.localizedMessage}"
            )
        }
    }

    suspend fun prepareSendMessage(recipient: String, messageText: String): ExecutionResult {
        return try {
            val sendIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://api.whatsapp.com/send?text=" + Uri.encode(messageText))
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(sendIntent)
            ExecutionResult(
                success = true,
                hindiResponse = "Bilkul, WhatsApp khol raha hoon aur $recipient ko sandesh bhejne ke liye chat tayar hai.",
                englishDetail = "Opened messaging intent for $recipient."
            )
        } catch (e: Exception) {
            ExecutionResult(
                success = false,
                hindiResponse = "Main ye action complete nahi kar paya.",
                englishDetail = "Failed to launch messaging app: ${e.localizedMessage}"
            )
        }
    }

    suspend fun handleUnknown(message: String): ExecutionResult {
        return ExecutionResult(
            success = false,
            hindiResponse = message,
            englishDetail = "Processed fallback response."
        )
    }

    private fun accessibilityServiceNotRunningResult(actionName: String): ExecutionResult {
        return ExecutionResult(
            success = false,
            hindiResponse = "$actionName karne ke liye Accessibility Service chalu honi chahiye. Kripya Settings mein jakar AI Assistant service ko chalu karein.",
            englishDetail = "Accessibility Service is not enabled. User must activate it in Android Settings."
        )
    }
}
