package com.aiassistant.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiassistant.app.model.AssistantStatus
import com.aiassistant.app.model.CommandHistoryItem
import com.aiassistant.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantScreen(
    status: AssistantStatus,
    isListening: Boolean,
    isSpeaking: Boolean,
    audioLevel: Float,
    recognizedCommand: String,
    assistantResponse: String,
    historyList: List<CommandHistoryItem>,
    isAccessibilityEnabled: Boolean,
    isMicPermissionGranted: Boolean,
    pendingConfirmationPrompt: String?,
    onMicClick: () -> Unit,
    onSendCommandText: (String) -> Unit,
    onOpenSettingsClick: () -> Unit,
    onNewConversationClick: () -> Unit,
    onDeleteHistoryItem: (String) -> Unit,
    onClearAllHistory: () -> Unit,
    onConfirmAction: () -> Unit,
    onCancelAction: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onRequestMicPermission: () -> Unit
) {
    var textInput by remember { mutableStateOf("") }
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.25f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = DarkBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            // --- 1. Top Header Bar ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(
                                Brush.linearGradient(listOf(AccentCyan, AccentCyanDark)),
                                RoundedCornerShape(10.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "AI Assistant",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (status) {
                                            AssistantStatus.READY -> StatusSuccess
                                            AssistantStatus.LISTENING -> StatusListening
                                            AssistantStatus.PROCESSING, AssistantStatus.EXECUTING -> AccentCyan
                                            AssistantStatus.SPEAKING -> StatusSpeaking
                                            AssistantStatus.ERROR -> StatusError
                                        }
                                    )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Status: ${status.name}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = onNewConversationClick,
                        modifier = Modifier
                            .size(38.dp)
                            .background(DarkSurfaceElevated, RoundedCornerShape(10.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddComment,
                            contentDescription = "New Conversation",
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = onOpenSettingsClick,
                        modifier = Modifier
                            .size(38.dp)
                            .background(DarkSurfaceElevated, RoundedCornerShape(10.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // --- 2. Permission Guidance Banners (if needed) ---
            if (!isMicPermissionGranted) {
                BannerCard(
                    text = "Microphone permission is required for voice commands.",
                    buttonLabel = "Grant",
                    onClick = onRequestMicPermission,
                    isWarning = true
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (!isAccessibilityEnabled) {
                BannerCard(
                    text = "Enable Accessibility Service for screen control & navigation.",
                    buttonLabel = "Enable",
                    onClick = onOpenAccessibilitySettings,
                    isWarning = false
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // --- 3. Live Active Interaction Display ---
            if (recognizedCommand.isNotBlank() || assistantResponse.isNotBlank()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(AccentCyanDark, DarkSurfaceBorder)))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        if (recognizedCommand.isNotBlank()) {
                            Text(
                                text = "You: $recognizedCommand",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        if (recognizedCommand.isNotBlank() && assistantResponse.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                        }
                        if (assistantResponse.isNotBlank()) {
                            Row(verticalAlignment = Alignment.Top) {
                                Icon(
                                    imageVector = Icons.Default.SmartToy,
                                    contentDescription = null,
                                    tint = AccentCyan,
                                    modifier = Modifier
                                        .size(18.dp)
                                        .padding(top = 2.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "AI Assistant: $assistantResponse",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = AccentCyanLight,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // --- 4. Conversation History Area ---
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (historyList.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterVertically,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hearing,
                            contentDescription = null,
                            tint = DarkSurfaceBorder,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Aap bol sakte hain:",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        listOf(
                            "\"YouTube kholo\"",
                            "\"WhatsApp kholo\"",
                            "\"Chrome kholo aur Google search karo\"",
                            "\"Home par jao\"",
                            "\"Neeche scroll karo\"",
                            "\"Volume kam karo\""
                        ).forEach { sample ->
                            Text(
                                text = sample,
                                color = AccentCyanLight,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier
                                    .clickable { onSendCommandText(sample.replace("\"", "")) }
                                    .padding(vertical = 2.dp)
                            )
                        }
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Conversation History",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Clear All",
                                style = MaterialTheme.typography.labelSmall,
                                color = StatusWarning,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { onClearAllHistory() }
                                    .padding(4.dp)
                            )
                        }
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(historyList, key = { it.id }) { item ->
                                HistoryBubble(
                                    item = item,
                                    onDeleteClick = { onDeleteHistoryItem(item.id) }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // --- 5. Voice Microphone Button (Centerpiece) ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer Pulse Ring
                if (isListening) {
                    Box(
                        modifier = Modifier
                            .size(86.dp)
                            .scale(pulseScale)
                            .background(AccentCyan.copy(alpha = 0.25f), CircleShape)
                    )
                }

                FloatingActionButton(
                    onClick = onMicClick,
                    shape = CircleShape,
                    containerColor = if (isListening) StatusListening else AccentCyan,
                    contentColor = Color.Black,
                    modifier = Modifier.size(68.dp)
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                        contentDescription = if (isListening) "Stop Listening" else "Start Listening",
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // --- 6. Text Input Field + Send Button ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("Command type karein ya mic dabayein...", fontSize = 13.sp, color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = AccentCyan,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            onSendCommandText(textInput.trim())
                            textInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(50.dp)
                        .background(
                            if (textInput.isNotBlank()) AccentCyan else DarkSurfaceElevated,
                            RoundedCornerShape(14.dp)
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = if (textInput.isNotBlank()) Color.Black else TextMuted
                    )
                }
            }
        }
    }

    // --- 7. Strict Safety Manager Confirmation Modal (Section 10) ---
    if (!pendingConfirmationPrompt.isNullOrBlank()) {
        AlertDialog(
            onDismissRequest = onCancelAction,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = StatusWarning,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Confirmation Required",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            },
            text = {
                Text(
                    text = pendingConfirmationPrompt,
                    color = TextPrimary,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = onConfirmAction,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusWarning),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Confirm", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onCancelAction,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkSurfaceElevated,
            shape = RoundedCornerShape(18.dp)
        )
    }
}

@Composable
private fun BannerCard(
    text: String,
    buttonLabel: String,
    onClick: () -> Unit,
    isWarning: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = if (isWarning) DarkSurfaceElevated else DarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(if (isWarning) StatusWarning else AccentCyan))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = text,
                color = TextPrimary,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = if (isWarning) StatusWarning else AccentCyan),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Text(
                    buttonLabel,
                    color = Color.Black,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun HistoryBubble(
    item: CommandHistoryItem,
    onDeleteClick: () -> Unit
) {
    val formatter = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val timeFormatted = formatter.format(Date(item.timestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(DarkSurfaceBorder))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "You: \"${item.userCommand}\"",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Delete",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.Top) {
                Icon(
                    imageVector = Icons.Default.SmartToy,
                    contentDescription = null,
                    tint = if (item.success) AccentCyan else StatusError,
                    modifier = Modifier
                        .size(16.dp)
                        .padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = item.assistantResponse,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (item.success) TextSecondary else StatusError
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = timeFormatted,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 10.sp,
                modifier = Modifier.align(Alignment.End)
            )
        }
    }
}
