package com.aiassistant.app.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.UUID

class VoiceResponseManager(
    private val context: Context,
    private val onSpeakingStateChanged: (Boolean) -> Unit
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var pendingSpeech: String? = null
    var isVoiceResponseEnabled: Boolean = true
    var currentLanguage: String = "Hindi" // "Hindi", "English", "Auto"

    companion object {
        private const val TAG = "VoiceResponseManager"
    }

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            applyLanguageConfig()

            tts?.setPitch(1.0f)
            tts?.setSpeechRate(0.95f)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    onSpeakingStateChanged(true)
                }

                override fun onDone(utteranceId: String?) {
                    onSpeakingStateChanged(false)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    onSpeakingStateChanged(false)
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    Log.e(TAG, "TTS Utterance error code: $errorCode")
                    onSpeakingStateChanged(false)
                }
            })

            isInitialized = true
            pendingSpeech?.let {
                speak(it)
                pendingSpeech = null
            }
        } else {
            Log.e(TAG, "TTS Initialization failed with status: $status")
        }
    }

    fun applyLanguageConfig() {
        if (!isInitialized || tts == null) return

        val locale = when (currentLanguage) {
            "English" -> Locale("en", "IN")
            "Hindi" -> Locale("hi", "IN")
            else -> Locale("hi", "IN") // Auto defaults to Hindi with English fallback
        }

        val langResult = tts?.setLanguage(locale)
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            Log.w(TAG, "Desired TTS language not fully supported, falling back to English (India)")
            tts?.setLanguage(Locale("en", "IN"))
        }
    }

    fun speak(text: String) {
        if (!isVoiceResponseEnabled) {
            onSpeakingStateChanged(false)
            return
        }

        if (!isInitialized || tts == null) {
            pendingSpeech = text
            return
        }

        val utteranceId = UUID.randomUUID().toString()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        onSpeakingStateChanged(false)
    }

    fun destroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
