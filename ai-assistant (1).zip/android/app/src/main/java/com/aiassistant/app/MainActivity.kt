package com.aiassistant.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.aiassistant.app.ai.*
import com.aiassistant.app.model.*
import com.aiassistant.app.repository.AssistantRepository
import com.aiassistant.app.safety.SafetyManager
import com.aiassistant.app.service.AssistantAccessibilityService
import com.aiassistant.app.ui.components.AssistantScreen
import com.aiassistant.app.ui.components.SettingsScreen
import com.aiassistant.app.ui.components.WelcomeDialog
import com.aiassistant.app.ui.theme.AiAssistantTheme
import com.aiassistant.app.voice.VoiceInputManager
import com.aiassistant.app.voice.VoiceResponseManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppScreen {
    MAIN,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    private lateinit var repository: AssistantRepository
    private lateinit var actionExecutor: AndroidActionExecutor
    private lateinit var actionPlanner: ActionPlanner
    private lateinit var aiProvider: AIProvider
    private var voiceInputManager: VoiceInputManager? = null
    private var voiceResponseManager: VoiceResponseManager? = null

    // Compose State Holders
    private var currentScreen by mutableStateOf(AppScreen.MAIN)
    private var assistantStatus by mutableStateOf(AssistantStatus.READY)
    private var isListening by mutableStateOf(false)
    private var isSpeaking by mutableStateOf(false)
    private var audioLevel by mutableStateOf(0f)
    private var recognizedCommand by mutableStateOf("")
    private var assistantResponse by mutableStateOf("")
    private var historyList by mutableStateOf<List<CommandHistoryItem>>(emptyList())
    private var appSettings by mutableStateOf(AppSettings())
    private var showWelcomeDialog by mutableStateOf(false)
    private var pendingIntentToConfirm by mutableStateOf<AssistantIntent?>(null)
    private var pendingConfirmationPrompt by mutableStateOf<String?>(null)

    private var isMicPermissionGranted by mutableStateOf(false)
    private var isNotificationPermissionGranted by mutableStateOf(false)

    // Permission Launchers
    private val requestRecordAudioLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        isMicPermissionGranted = isGranted
        if (isGranted) {
            initVoiceInput()
            startListeningForCommand()
        } else {
            Toast.makeText(this, "Microphone permission is required for voice commands", Toast.LENGTH_LONG).show()
        }
    }

    private val requestNotificationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        isNotificationPermissionGranted = isGranted
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Core Dependencies
        repository = AssistantRepository(this)
        appSettings = repository.getSettings()
        historyList = repository.getHistory()
        showWelcomeDialog = repository.isFirstLaunch()

        actionExecutor = AndroidActionExecutor(this)
        actionPlanner = ActionPlanner(actionExecutor)
        aiProvider = if (appSettings.isAiProviderConfigured && appSettings.aiApiKey.isNotBlank()) {
            ConfigurableAiProvider(apiKey = appSettings.aiApiKey, endpointUrl = appSettings.customAiEndpoint)
        } else {
            LocalOfflineAiProvider()
        }

        // Initialize Voice Response Manager (TTS)
        voiceResponseManager = VoiceResponseManager(this) { speaking ->
            isSpeaking = speaking
            if (speaking) {
                assistantStatus = AssistantStatus.SPEAKING
            } else if (assistantStatus == AssistantStatus.SPEAKING) {
                assistantStatus = AssistantStatus.READY
            }
        }.apply {
            isVoiceResponseEnabled = appSettings.isVoiceResponseEnabled
            currentLanguage = appSettings.language
        }

        checkPermissions()

        setContent {
            AiAssistantTheme {
                val isAccessibilityConnected by AssistantAccessibilityService.isServiceConnected.collectAsState()

                if (currentScreen == AppScreen.SETTINGS) {
                    SettingsScreen(
                        settings = appSettings,
                        isMicPermissionGranted = isMicPermissionGranted,
                        isNotificationPermissionGranted = isNotificationPermissionGranted,
                        isAccessibilityEnabled = isAccessibilityConnected,
                        onBackClick = { currentScreen = AppScreen.MAIN },
                        onVoiceResponseToggled = { enabled ->
                            val updated = appSettings.copy(isVoiceResponseEnabled = enabled)
                            appSettings = updated
                            repository.saveSettings(updated)
                            voiceResponseManager?.isVoiceResponseEnabled = enabled
                        },
                        onLanguageSelected = { lang ->
                            val updated = appSettings.copy(language = lang)
                            appSettings = updated
                            repository.saveSettings(updated)
                            voiceResponseManager?.currentLanguage = lang
                            voiceResponseManager?.applyLanguageConfig()
                        },
                        onOpenAccessibilitySettings = { openAccessibilitySettings() },
                        onRequestMicPermission = { requestMicPermission() },
                        onRequestNotificationPermission = { requestNotificationPermission() },
                        onSaveAiConfig = { apiKey, endpoint ->
                            val configured = apiKey.isNotBlank()
                            val updated = appSettings.copy(
                                isAiProviderConfigured = configured,
                                aiApiKey = apiKey,
                                customAiEndpoint = endpoint
                            )
                            appSettings = updated
                            repository.saveSettings(updated)
                            aiProvider = if (configured) {
                                ConfigurableAiProvider(apiKey = apiKey, endpointUrl = endpoint)
                            } else {
                                LocalOfflineAiProvider()
                            }
                        }
                    )
                } else {
                    AssistantScreen(
                        status = assistantStatus,
                        isListening = isListening,
                        isSpeaking = isSpeaking,
                        audioLevel = audioLevel,
                        recognizedCommand = recognizedCommand,
                        assistantResponse = assistantResponse,
                        historyList = historyList,
                        isAccessibilityEnabled = isAccessibilityConnected,
                        isMicPermissionGranted = isMicPermissionGranted,
                        pendingConfirmationPrompt = pendingConfirmationPrompt,
                        onMicClick = { handleMicButtonClick() },
                        onSendCommandText = { text -> handleUserCommand(text) },
                        onOpenSettingsClick = { currentScreen = AppScreen.SETTINGS },
                        onNewConversationClick = { handleNewConversation() },
                        onDeleteHistoryItem = { id ->
                            repository.deleteHistoryItem(id)
                            historyList = repository.getHistory()
                        },
                        onClearAllHistory = {
                            repository.clearHistory()
                            historyList = emptyList()
                        },
                        onConfirmAction = { executeConfirmedPendingAction() },
                        onCancelAction = { cancelPendingAction() },
                        onOpenAccessibilitySettings = { openAccessibilitySettings() },
                        onRequestMicPermission = { requestMicPermission() }
                    )
                }

                // Welcome Dialog on First Launch (Section 22)
                if (showWelcomeDialog) {
                    WelcomeDialog(
                        onDismiss = {
                            showWelcomeDialog = false
                            repository.setFirstLaunchCompleted()
                        }
                    )
                }
            }
        }
    }

    private fun checkPermissions() {
        isMicPermissionGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            isNotificationPermissionGranted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            isNotificationPermissionGranted = true
        }

        if (isMicPermissionGranted) {
            initVoiceInput()
        }
    }

    private fun initVoiceInput() {
        if (voiceInputManager != null) return

        voiceInputManager = VoiceInputManager(
            context = this,
            onSpeechResult = { recognizedText ->
                handleUserCommand(recognizedText)
            },
            onListeningStateChanged = { listening ->
                isListening = listening
                if (listening) {
                    assistantStatus = AssistantStatus.LISTENING
                } else if (assistantStatus == AssistantStatus.LISTENING) {
                    assistantStatus = AssistantStatus.PROCESSING
                }
            },
            onAudioLevelChanged = { level ->
                audioLevel = level
            },
            onErrorOccurred = { errorMsg ->
                assistantStatus = AssistantStatus.ERROR
                assistantResponse = errorMsg
            }
        )
    }

    private fun handleMicButtonClick() {
        if (!isMicPermissionGranted) {
            requestMicPermission()
            return
        }

        if (isListening) {
            voiceInputManager?.stopListening()
        } else {
            // Stop speech if speaking
            voiceResponseManager?.stop()
            startListeningForCommand()
        }
    }

    private fun startListeningForCommand() {
        initVoiceInput()
        assistantStatus = AssistantStatus.LISTENING
        recognizedCommand = ""
        assistantResponse = ""
        voiceInputManager?.startListening()
    }

    private fun handleUserCommand(command: String) {
        if (command.isBlank()) return

        recognizedCommand = command
        assistantStatus = AssistantStatus.PROCESSING

        lifecycleScope.launch {
            try {
                // 1. Context & Screen text extraction if available
                val screenContext = AssistantAccessibilityService.instance?.extractCurrentScreenTexts() ?: emptyList()

                // 2. AI Command Understanding
                val intent = aiProvider.understandCommand(command, screenContext.take(5).joinToString(", "))

                // 3. Safety Check: If action is sensitive, request confirmation first
                if (SafetyManager.isActionSensitive(intent)) {
                    val prompt = SafetyManager.getConfirmationPrompt(intent)
                    pendingIntentToConfirm = intent
                    pendingConfirmationPrompt = prompt
                    assistantStatus = AssistantStatus.READY
                    voiceResponseManager?.speak(prompt)
                    return@launch
                }

                // 4. Action Execution
                executeIntent(intent, command)

            } catch (e: Exception) {
                assistantStatus = AssistantStatus.ERROR
                val failMsg = "Main ye action complete nahi kar paya."
                assistantResponse = failMsg
                voiceResponseManager?.speak(failMsg)
                recordHistory(command, failMsg, success = false)
            }
        }
    }

    private fun executeConfirmedPendingAction() {
        val intent = pendingIntentToConfirm ?: return
        val command = intent.rawQuery
        pendingIntentToConfirm = null
        pendingConfirmationPrompt = null

        lifecycleScope.launch {
            executeIntent(intent, command)
        }
    }

    private fun cancelPendingAction() {
        val command = pendingIntentToConfirm?.rawQuery ?: recognizedCommand
        pendingIntentToConfirm = null
        pendingConfirmationPrompt = null
        assistantStatus = AssistantStatus.READY
        val cancelMsg = "Kriya radd kar di gayi hai (Action cancelled)."
        assistantResponse = cancelMsg
        voiceResponseManager?.speak(cancelMsg)
        recordHistory(command, cancelMsg, success = true)
    }

    private suspend fun executeIntent(intent: AssistantIntent, commandText: String) {
        assistantStatus = AssistantStatus.EXECUTING

        val steps = actionPlanner.plan(intent)
        var allSuccess = true
        var finalResponse = ""

        for (step in steps) {
            val result = step.execute()
            finalResponse = result.hindiResponse
            if (!result.success) {
                allSuccess = false
                break
            }
            delay(300) // Small organic pause between multi-step actions
        }

        assistantResponse = finalResponse
        assistantStatus = if (allSuccess) AssistantStatus.READY else AssistantStatus.ERROR

        // Speak natural voice response in Hindi if voice responses are enabled
        voiceResponseManager?.speak(finalResponse)

        // Persist to local conversation history
        recordHistory(commandText, finalResponse, allSuccess)
    }

    private fun recordHistory(command: String, response: String, success: Boolean) {
        val item = CommandHistoryItem(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            userCommand = command,
            assistantResponse = response,
            status = if (success) "SUCCESS" else "FAILED",
            success = success
        )
        repository.addHistoryItem(item)
        historyList = repository.getHistory()
    }

    private fun handleNewConversation() {
        recognizedCommand = ""
        assistantResponse = ""
        pendingIntentToConfirm = null
        pendingConfirmationPrompt = null
        assistantStatus = AssistantStatus.READY
        voiceResponseManager?.stop()
    }

    private fun openAccessibilitySettings() {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open Accessibility Settings", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestMicPermission() {
        requestRecordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceInputManager?.destroy()
        voiceResponseManager?.destroy()
    }
}
