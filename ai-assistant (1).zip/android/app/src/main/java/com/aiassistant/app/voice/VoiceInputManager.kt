package com.aiassistant.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log

class VoiceInputManager(
    private val context: Context,
    private val onSpeechResult: (String) -> Unit,
    private val onListeningStateChanged: (Boolean) -> Unit,
    private val onAudioLevelChanged: (Float) -> Unit,
    private val onErrorOccurred: (String) -> Unit
) : RecognitionListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    companion object {
        private const val TAG = "VoiceInputManager"
    }

    init {
        initRecognizer()
    }

    private fun initRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(this@VoiceInputManager)
            }
        } else {
            Log.e(TAG, "Speech recognition is not available on this device.")
            onErrorOccurred("डिवाइस पर वॉइस पहचान उपलब्ध नहीं है (Speech recognition unavailable)")
        }
    }

    fun startListening() {
        if (speechRecognizer == null) {
            initRecognizer()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // Prioritize Hindi (India) with Hinglish/Indian English support
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayOf("hi-IN", "en-IN"))
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        try {
            speechRecognizer?.startListening(intent)
            isListening = true
            onListeningStateChanged(true)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start speech recognition: ${e.message}", e)
            onErrorOccurred("माइक्रोफ़ोन प्रारंभ नहीं हो सका: ${e.localizedMessage}")
            onListeningStateChanged(false)
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recognizer: ${e.message}")
        }
        isListening = false
        onListeningStateChanged(false)
    }

    fun cancel() {
        try {
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            Log.e(TAG, "Error cancelling recognizer: ${e.message}")
        }
        isListening = false
        onListeningStateChanged(false)
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying recognizer: ${e.message}")
        }
        speechRecognizer = null
        isListening = false
    }

    // --- RecognitionListener Callbacks ---

    override fun onReadyForSpeech(params: Bundle?) {
        Log.d(TAG, "Ready for speech")
        onListeningStateChanged(true)
    }

    override fun onBeginningOfSpeech() {
        Log.d(TAG, "Speech started")
    }

    override fun onRmsChanged(rmsdB: Float) {
        // Normalize typical rms range [-2, 10] to [0.0, 1.0]
        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        onAudioLevelChanged(normalized)
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        Log.d(TAG, "End of speech")
        isListening = false
        onListeningStateChanged(false)
    }

    override fun onError(error: Int) {
        isListening = false
        onListeningStateChanged(false)
        onAudioLevelChanged(0f)

        val message = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "ऑडियो रिकॉर्डिंग त्रुटि (Audio recording error)"
            SpeechRecognizer.ERROR_CLIENT -> "क्लाइंट त्रुटि (Client error)"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "माइक्रोफ़ोन अनुमति आवश्यक है (Microphone permission required)"
            SpeechRecognizer.ERROR_NETWORK -> "नेटवर्क त्रुटि (Network error)"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "नेटवर्क टाइमआउट (Network timeout)"
            SpeechRecognizer.ERROR_NO_MATCH -> "कुछ सुनाई नहीं दिया, कृपया पुनः प्रयास करें (No match, please try again)"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "वॉइस इंजन व्यस्त है (Recognizer busy)"
            SpeechRecognizer.ERROR_SERVER -> "सर्वर त्रुटि (Server error)"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "कोई आवाज़ नहीं मिली (Speech timeout)"
            else -> "त्रुटि ($error)"
        }
        Log.w(TAG, "SpeechRecognizer Error: $error -> $message")
        onErrorOccurred(message)
    }

    override fun onResults(results: Bundle?) {
        isListening = false
        onListeningStateChanged(false)
        onAudioLevelChanged(0f)

        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val recognizedText = matches[0].trim()
            Log.d(TAG, "Recognized command: $recognizedText")
            onSpeechResult(recognizedText)
        } else {
            onErrorOccurred("कोई कमांड नहीं पहचानी गई (No command detected)")
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {}

    override fun onEvent(eventType: Int, params: Bundle?) {}
}
