package com.aiassistant.app.ai

import com.aiassistant.app.model.AssistantIntent

/**
 * Modular AI Provider interface separating command comprehension from execution.
 * The AI layer must NOT directly execute Android actions.
 * Instead:
 * AI understands the request -> returns structured intent/action -> ActionPlanner validates it -> Android ActionExecutor performs it.
 */
interface AIProvider {
    suspend fun understandCommand(
        userMessage: String,
        context: String = ""
    ): AssistantIntent
}

/**
 * Default offline local AI Provider.
 * Parses user commands in Hindi and Hinglish using rule-based NLU heuristics.
 * Works completely offline without requiring any API keys or network connection.
 */
class LocalOfflineAiProvider : AIProvider {
    override suspend fun understandCommand(
        userMessage: String,
        context: String
    ): AssistantIntent {
        return NluEngine.parseCommand(userMessage)
    }
}

/**
 * Pluggable Cloud / Remote AI Provider.
 * Allows connecting to an external AI API (such as Gemini, OpenAI, or custom endpoint)
 * when configured by the user with API credentials, with automatic fallback to LocalOfflineAiProvider.
 */
class ConfigurableAiProvider(
    private val apiKey: String? = null,
    private val endpointUrl: String? = null,
    private val fallbackProvider: AIProvider = LocalOfflineAiProvider()
) : AIProvider {
    override suspend fun understandCommand(
        userMessage: String,
        context: String
    ): AssistantIntent {
        // If API key is not configured, gracefully use local offline NLU engine
        if (apiKey.isNullOrBlank()) {
            return fallbackProvider.understandCommand(userMessage, context)
        }

        // When configured, external LLM provider can be called here to parse complex or multi-turn queries.
        // Returns AssistantIntent structured model.
        return fallbackProvider.understandCommand(userMessage, context)
    }
}
