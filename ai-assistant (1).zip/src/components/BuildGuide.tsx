import React, { useState } from 'react';
import { Download, Terminal, CheckCircle, Shield, Mic, Play, Smartphone, ArrowRight } from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_FILES } from '../androidProjectFiles';

interface BuildGuideProps {
  onDownloadZip?: () => void;
}

export const BuildGuide: React.FC<BuildGuideProps> = ({ onDownloadZip }) => {
  const [downloading, setDownloading] = useState(false);

  const handleDownloadZip = async () => {
    if (onDownloadZip) {
      onDownloadZip();
      return;
    }
    try {
      setDownloading(true);
      const zip = new JSZip();

      // Add all Android files to zip
      for (const file of ANDROID_FILES) {
        zip.file(file.path, file.content);
      }

      // Add gradlew stub and readme
      zip.file(
        'README.md',
        `# AI Assistant - Native Android Voice Assistant

A real native Android application in Kotlin & Jetpack Compose for voice-controlled phone automation in Hindi and Hinglish.

## How to Build
1. Open this folder in Android Studio (Giraffe / Hedgehog / Iguana or later).
2. Wait for Gradle sync to finish.
3. Run \`./gradlew assembleDebug\` or click **Run 'app'**.
4. Install on your Android device (Android 8.0+ / API 26+).
5. Grant Microphone permission and enable **AI Assistant Phone Controller** in Accessibility Settings.
`
      );

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'ai-assistant-android-native-project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Download failed:', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col gap-6 select-text">
      {/* Top Banner with ZIP Download */}
      <div className="bg-gradient-to-r from-cyan-950/80 via-slate-900 to-indigo-950/80 border border-cyan-700/50 rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-cyan-400" />
            Complete Native Android Project Ready
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            Built using modern Kotlin, Jetpack Compose Material 3, Android AccessibilityService, and SpeechRecognizer with Hindi & Hinglish natural language parsing.
          </p>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={downloading}
          className="bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white font-semibold text-xs px-5 py-3 rounded-xl flex items-center gap-2 shadow-lg transition-all shrink-0 cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>{downloading ? 'Preparing ZIP...' : 'Download Android Project (ZIP)'}</span>
        </button>
      </div>

      {/* 5-Step Instructions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Step 1: Build APK */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-700 flex items-center justify-center text-cyan-300 font-bold text-sm">
              1
            </div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              Build the Android APK
            </h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Open the downloaded project folder in <strong>Android Studio</strong> or run the standard Gradle command in your terminal:
          </p>
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-xs text-cyan-300">
            cd android/<br />
            ./gradlew assembleDebug
          </div>
          <p className="text-[11px] text-slate-400">
            Output APK location: <br />
            <code className="text-slate-300">app/build/outputs/apk/debug/app-debug.apk</code>
          </p>
        </div>

        {/* Step 2: Install APK */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-700 flex items-center justify-center text-cyan-300 font-bold text-sm">
              2
            </div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              Install on Your Phone
            </h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Connect your Android phone via USB with <strong>USB Debugging</strong> enabled and run:
          </p>
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-xs text-cyan-300">
            adb install -r app/build/outputs/apk/debug/app-debug.apk
          </div>
          <p className="text-[11px] text-slate-400">
            Alternatively: Transfer <code>app-debug.apk</code> to your phone and tap to install (allow "Install from Unknown Sources" if prompted).
          </p>
        </div>

        {/* Step 3: Enable Mic Permission */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-700 flex items-center justify-center text-cyan-300 font-bold text-sm">
              3
            </div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Mic className="w-4 h-4 text-cyan-400" />
              Enable Microphone Permission
            </h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            When you open <strong>AI Assistant</strong> for the first time, tap the Microphone button or the "अनुमति दें" badge:
          </p>
          <ul className="text-xs text-slate-300 list-disc list-inside space-y-1">
            <li>Select <strong>"While using the app"</strong> on the Android dialog.</li>
            <li>Or grant via ADB: <code className="text-cyan-300">adb shell pm grant com.aiassistant.app android.permission.RECORD_AUDIO</code></li>
          </ul>
        </div>

        {/* Step 4: Enable Accessibility Service */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-700 flex items-center justify-center text-cyan-300 font-bold text-sm">
              4
            </div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-cyan-400" />
              Enable Accessibility Service
            </h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Accessibility Service is required to perform physical touches and global navigation:
          </p>
          <ol className="text-xs text-slate-300 list-decimal list-inside space-y-1">
            <li>Open phone <strong>Settings → Accessibility</strong> (or tap "चालू करें" in app).</li>
            <li>Tap <strong>Installed Apps / Services</strong>.</li>
            <li>Select <strong>AI Assistant Phone Controller</strong> and toggle it <strong>ON</strong>.</li>
            <li>Confirm the prompt allowing screen interaction.</li>
          </ol>
        </div>
      </div>

      {/* Step 5: Testing the command */}
      <div className="bg-slate-900 border border-emerald-700/60 rounded-2xl p-6 shadow-xl flex flex-col gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-600 flex items-center justify-center text-emerald-300 font-bold text-base">
            5
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Play className="w-4 h-4 text-emerald-400" />
              Test the Command: "YouTube kholo"
            </h3>
            <p className="text-xs text-slate-400">Step-by-step verification on your phone</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <span className="text-[10px] font-bold text-cyan-400 uppercase">Action 1</span>
            <p className="text-xs text-slate-200 font-medium mt-1">Tap the Glowing Mic Button</p>
            <p className="text-[11px] text-slate-400 mt-1">
              The status changes to <em>"बोलिए, सुन रहे हैं…" (Listening…)</em> with audio wave animation.
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <span className="text-[10px] font-bold text-cyan-400 uppercase">Action 2</span>
            <p className="text-xs text-slate-200 font-medium mt-1">Speak: "YouTube kholo"</p>
            <p className="text-[11px] text-slate-400 mt-1">
              SpeechRecognizer converts speech to text. NLU identifies <code>Intent.LaunchApp(appName="YouTube", pkg="com.google.android.youtube")</code>.
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <span className="text-[10px] font-bold text-cyan-400 uppercase">Action 3</span>
            <p className="text-xs text-slate-200 font-medium mt-1">Execution & Voice Response</p>
            <p className="text-[11px] text-slate-400 mt-1">
              YouTube opens on your screen immediately, and the assistant responds in Hindi: <em>"YouTube खोला जा रहा है।"</em>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
