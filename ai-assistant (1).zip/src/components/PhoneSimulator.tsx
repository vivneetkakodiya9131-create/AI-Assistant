import React, { useState } from 'react';
import {
  Mic,
  Volume2,
  VolumeX,
  Search,
  ArrowLeft,
  Square,
  Circle,
  Triangle,
  Play,
  MessageSquare,
  Camera,
  Settings as SettingsIcon,
  ShieldAlert,
  Sparkles,
  Globe,
  Send,
  Trash2,
  X,
  PlusCircle,
  CheckCircle2,
  Sliders,
  ChevronRight,
  Info
} from 'lucide-react';
import { AssistantStatus, CommandLog, SimulatedScreen } from '../types';

interface PhoneSimulatorProps {
  status: AssistantStatus;
  recognizedText: string;
  assistantResponse: string;
  activeScreen: SimulatedScreen;
  volumeLevel: number;
  isMuted: boolean;
  micPermission: boolean;
  accessibilityPermission: boolean;
  history: CommandLog[];
  safetyPrompt: string | null;
  voiceResponseEnabled: boolean;
  selectedLanguage: string;
  onMicClick: () => void;
  onSendCommandText: (cmd: string) => void;
  onConfirmSafety: (allow: boolean) => void;
  onToggleMicPermission: () => void;
  onToggleAccessibility: () => void;
  onToggleVoiceResponse: () => void;
  onSelectLanguage: (lang: 'Hindi' | 'English' | 'Auto') => void;
  onNavAction: (action: 'BACK' | 'HOME' | 'RECENTS') => void;
  onScreenElementClick: (elementName: string) => void;
  onDeleteHistoryItem: (id: string) => void;
  onClearHistory: () => void;
  onNewConversation: () => void;
}

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({
  status,
  recognizedText,
  assistantResponse,
  activeScreen,
  volumeLevel,
  isMuted,
  micPermission,
  accessibilityPermission,
  history,
  safetyPrompt,
  voiceResponseEnabled,
  selectedLanguage,
  onMicClick,
  onSendCommandText,
  onConfirmSafety,
  onToggleMicPermission,
  onToggleAccessibility,
  onToggleVoiceResponse,
  onSelectLanguage,
  onNavAction,
  onScreenElementClick,
  onDeleteHistoryItem,
  onClearHistory,
  onNewConversation
}) => {
  const [typedInput, setTypedInput] = useState('');
  const [showSettingsView, setShowSettingsView] = useState(false);
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'interactive' | 'logs'>('interactive');

  const handleSend = () => {
    if (typedInput.trim()) {
      onSendCommandText(typedInput.trim());
      setTypedInput('');
    }
  };

  const sampleCommands = [
    { label: 'YouTube kholo', cmd: 'YouTube kholo' },
    { label: 'WhatsApp kholo', cmd: 'WhatsApp kholo' },
    { label: 'Chrome kholo', cmd: 'Chrome kholo' },
    { label: 'Home par jao', cmd: 'Home par jao' },
    { label: 'Back jao', cmd: 'Back jao' },
    { label: 'Recent apps dikhao', cmd: 'Recent apps dikhao' },
    { label: 'Search dabao', cmd: 'Screen par jo Search button hai use dabao' },
    { label: 'Neeche scroll karo', cmd: 'Neeche scroll karo' },
    { label: 'Volume kam karo', cmd: 'Volume kam karo' },
    { label: 'Message bhejo (Safety)', cmd: 'WhatsApp mein Amit ko message bhejo' },
    { label: 'Uninstalled app test', cmd: 'Netflix kholo' }
  ];

  return (
    <div className="flex flex-col xl:flex-row gap-6 w-full items-start justify-center">
      {/* Phone Mockup Frame */}
      <div className="flex flex-col items-center">
        <div className="relative w-[340px] sm:w-[380px] h-[750px] bg-slate-950 rounded-[48px] p-3 shadow-2xl border-[6px] border-slate-800 flex flex-col justify-between overflow-hidden ring-1 ring-slate-700/50">
          
          {/* Top Notch / Dynamic Island */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-full z-40 flex items-center justify-center">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700 mr-2" />
            <div className="w-2 h-2 rounded-full bg-emerald-950 border border-emerald-500/40" />
          </div>

          {/* Android Status Bar */}
          <div className="relative z-30 pt-1 px-5 flex justify-between items-center text-xs text-slate-300 select-none">
            <span className="font-semibold text-slate-200">12:30</span>
            <div className="flex items-center gap-1.5 text-[10px]">
              <span className="bg-slate-800 px-1 py-0.5 rounded text-[9px] font-mono text-cyan-300">5G</span>
              <span>100%</span>
            </div>
          </div>

          {/* Volume HUD (shows when volume changes) */}
          <div className="absolute top-12 right-3 z-30 bg-slate-900/90 backdrop-blur border border-slate-700/80 rounded-xl p-2 flex flex-col items-center gap-1 shadow-lg">
            {isMuted ? (
              <VolumeX className="w-4 h-4 text-red-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-cyan-400" />
            )}
            <div className="w-1.5 h-16 bg-slate-800 rounded-full overflow-hidden flex flex-col justify-end">
              <div
                className="w-full bg-cyan-500 transition-all duration-300"
                style={{ height: `${isMuted ? 0 : volumeLevel}%` }}
              />
            </div>
            <span className="text-[9px] font-mono text-slate-300">{isMuted ? '0' : volumeLevel}%</span>
          </div>

          {/* Active Screen Content (simulating phone background app) */}
          <div className="relative flex-1 rounded-[32px] overflow-hidden bg-slate-900 flex flex-col my-1 select-none border border-slate-800/60">
            {showSettingsView ? (
              /* In-Phone Settings Screen */
              <div className="w-full h-full bg-slate-950 text-slate-200 p-4 flex flex-col gap-3 overflow-y-auto">
                <div className="flex items-center gap-2 border-b border-slate-800 pb-2.5">
                  <button
                    onClick={() => setShowSettingsView(false)}
                    className="p-1 rounded-lg bg-slate-900 hover:bg-slate-800"
                  >
                    <ArrowLeft className="w-4 h-4 text-slate-300" />
                  </button>
                  <h2 className="text-sm font-bold text-white">Assistant Settings</h2>
                </div>

                <div className="flex flex-col gap-2.5 text-xs">
                  {/* Voice Response */}
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-white">Voice Response</p>
                      <p className="text-[10px] text-slate-400">{voiceResponseEnabled ? 'Speaking ON (Hindi TTS)' : 'Muted (Text only)'}</p>
                    </div>
                    <button
                      onClick={onToggleVoiceResponse}
                      className={`px-3 py-1 rounded-full text-[11px] font-bold ${
                        voiceResponseEnabled ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {voiceResponseEnabled ? 'ON' : 'OFF'}
                    </button>
                  </div>

                  {/* Language selection */}
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex flex-col gap-2">
                    <p className="font-semibold text-white">Language (भाषा)</p>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['Hindi', 'English', 'Auto'] as const).map((lang) => (
                        <button
                          key={lang}
                          onClick={() => onSelectLanguage(lang)}
                          className={`py-1 rounded-lg text-[10px] font-bold border transition-colors ${
                            selectedLanguage === lang
                              ? 'bg-cyan-600 border-cyan-400 text-white'
                              : 'bg-slate-800 border-slate-700 text-slate-300'
                          }`}
                        >
                          {lang}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Accessibility Service */}
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-white">Accessibility Service</p>
                      <p className="text-[10px] text-slate-400">Back, Home, Click & Scroll</p>
                    </div>
                    <button
                      onClick={onToggleAccessibility}
                      className={`px-3 py-1 rounded-full text-[11px] font-bold ${
                        accessibilityPermission ? 'bg-emerald-500 text-slate-950' : 'bg-amber-500 text-slate-950'
                      }`}
                    >
                      {accessibilityPermission ? 'ENABLED' : 'DISABLED'}
                    </button>
                  </div>

                  {/* Microphone */}
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-white">Microphone</p>
                      <p className="text-[10px] text-slate-400">RECORD_AUDIO Permission</p>
                    </div>
                    <button
                      onClick={onToggleMicPermission}
                      className={`px-3 py-1 rounded-full text-[11px] font-bold ${
                        micPermission ? 'bg-emerald-500 text-slate-950' : 'bg-amber-500 text-slate-950'
                      }`}
                    >
                      {micPermission ? 'GRANTED' : 'DENIED'}
                    </button>
                  </div>

                  {/* AI Provider */}
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-white">AI Provider</p>
                      <p className="text-[10px] text-slate-400">Local Offline NLU (Active)</p>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-mono">READY</span>
                  </div>

                  {/* About */}
                  <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 text-[10px] text-slate-400 flex flex-col gap-1">
                    <p className="font-semibold text-slate-300">About App</p>
                    <p>Version: 1.0.0 (Native Android Release)</p>
                    <p>Engine: Kotlin + Compose + Accessibility</p>
                  </div>
                </div>
              </div>
            ) : activeScreen === 'HOME' ? (
              <div className="w-full h-full p-4 flex flex-col justify-between bg-gradient-to-b from-slate-950 via-slate-900 to-cyan-950/40">
                {/* Search Widget with Search Button (targets Accessibility Click test) */}
                <div className="pt-8">
                  <div className="bg-slate-800/90 backdrop-blur rounded-2xl p-2.5 px-4 flex items-center justify-between border border-slate-700/60 shadow-sm">
                    <span className="text-slate-400 text-xs flex items-center gap-2">
                      <Globe className="w-4 h-4 text-cyan-400" /> Google search...
                    </span>
                    <button
                      id="simulated-search-button"
                      onClick={() => onScreenElementClick('Search')}
                      className="bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-medium px-3 py-1 rounded-xl flex items-center gap-1 transition-all active:scale-95 shadow-sm"
                    >
                      <Search className="w-3 h-3" />
                      <span>Search</span>
                    </button>
                  </div>
                  <p className="text-[10px] text-cyan-400/80 text-center mt-1.5">
                    (accessibility node: id=search_button, text="Search")
                  </p>
                </div>

                {/* Grid of Apps */}
                <div className="grid grid-cols-4 gap-3 text-center my-auto">
                  <div
                    onClick={() => onScreenElementClick('YouTube')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="w-12 h-12 bg-red-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                      <Play className="w-6 h-6 text-white fill-white" />
                    </div>
                    <span className="text-[11px] text-slate-200 font-medium">YouTube</span>
                  </div>

                  <div
                    onClick={() => onScreenElementClick('Chrome')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                      <Globe className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-[11px] text-slate-200 font-medium">Chrome</span>
                  </div>

                  <div
                    onClick={() => onScreenElementClick('WhatsApp')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                      <MessageSquare className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-[11px] text-slate-200 font-medium">WhatsApp</span>
                  </div>

                  <div
                    onClick={() => onScreenElementClick('Camera')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="w-12 h-12 bg-slate-700 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                      <Camera className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-[11px] text-slate-200 font-medium">Camera</span>
                  </div>
                </div>

                {/* Dock apps */}
                <div className="bg-slate-800/60 backdrop-blur rounded-2xl p-2.5 flex justify-around border border-slate-700/40">
                  <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white text-xs font-bold">
                    Phone
                  </div>
                  <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white text-xs font-bold">
                    SMS
                  </div>
                  <div
                    onClick={() => onScreenElementClick('Settings')}
                    className="w-10 h-10 bg-slate-700 rounded-xl flex items-center justify-center text-white text-xs font-bold cursor-pointer"
                  >
                    <SettingsIcon className="w-5 h-5 text-slate-200" />
                  </div>
                </div>
              </div>
            ) : activeScreen === 'YOUTUBE' ? (
              <div className="w-full h-full bg-slate-950 text-white flex flex-col">
                <div className="p-3 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Play className="w-5 h-5 text-red-600 fill-red-600" />
                    <span className="font-bold text-sm">YouTube</span>
                  </div>
                  <Search className="w-4 h-4 text-slate-400" />
                </div>
                <div className="p-3 flex-1 flex flex-col gap-3 overflow-y-auto">
                  <div className="h-32 bg-slate-800 rounded-xl flex flex-col justify-end p-3 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-center">
                      <Play className="w-10 h-10 text-white/80 fill-white/80" />
                    </div>
                    <span className="text-xs font-semibold relative z-10">Free Fire Highlights</span>
                    <span className="text-[10px] text-slate-400 relative z-10">Gaming • 1.2M views</span>
                  </div>
                  <div className="h-28 bg-slate-800/80 rounded-xl flex flex-col justify-end p-2.5">
                    <span className="text-xs font-medium">Hindi Songs Playlist</span>
                    <span className="text-[10px] text-slate-400">Music • 500K views</span>
                  </div>
                </div>
              </div>
            ) : activeScreen === 'CHROME' ? (
              <div className="w-full h-full bg-slate-900 text-slate-200 flex flex-col">
                <div className="p-2.5 bg-slate-950 border-b border-slate-800 flex items-center gap-2">
                  <div className="flex-1 bg-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-300 flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5 text-cyan-400" />
                    <span>google.com</span>
                  </div>
                </div>
                <div className="flex-1 p-4 flex flex-col items-center justify-center text-center">
                  <Globe className="w-12 h-12 text-cyan-500 mb-2" />
                  <p className="font-semibold text-sm">Google Chrome</p>
                  <p className="text-xs text-slate-400 mt-1">Browser active</p>
                </div>
              </div>
            ) : activeScreen === 'WHATSAPP' ? (
              <div className="w-full h-full bg-slate-950 text-white flex flex-col">
                <div className="bg-emerald-900/60 p-3 flex items-center justify-between border-b border-emerald-800/40">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center font-bold text-xs">
                      A
                    </div>
                    <div>
                      <p className="text-xs font-semibold">Amit</p>
                      <p className="text-[10px] text-emerald-400">Online</p>
                    </div>
                  </div>
                </div>
                <div className="flex-1 p-3 flex flex-col justify-end gap-2 text-xs">
                  <div className="bg-slate-800 p-2.5 rounded-xl rounded-bl-none self-start max-w-[80%] text-slate-200">
                    Bhai kahan ho?
                  </div>
                  <div className="bg-emerald-700 p-2.5 rounded-xl rounded-br-none self-end max-w-[80%] text-white">
                    Main abhi AI Assistant test kar raha hoon!
                  </div>
                </div>
              </div>
            ) : activeScreen === 'CAMERA' ? (
              <div className="w-full h-full bg-black flex flex-col justify-between p-4 text-white">
                <div className="flex justify-between text-xs text-slate-400">
                  <span>HDR</span>
                  <span>4K 60FPS</span>
                </div>
                <div className="self-center w-36 h-36 border border-dashed border-white/40 rounded-xl flex items-center justify-center">
                  <Camera className="w-8 h-8 text-white/60" />
                </div>
                <div className="flex justify-around items-center pt-2">
                  <div className="w-7 h-7 rounded-full bg-slate-800" />
                  <div className="w-12 h-12 rounded-full border-4 border-white flex items-center justify-center">
                    <div className="w-9 h-9 rounded-full bg-white active:scale-90 transition-transform" />
                  </div>
                  <div className="w-7 h-7 rounded-full bg-slate-800" />
                </div>
              </div>
            ) : activeScreen === 'RECENTS' ? (
              <div className="w-full h-full bg-slate-950/90 p-4 flex flex-col items-center justify-center gap-3">
                <p className="text-xs font-semibold text-slate-300">Recent Applications</p>
                <div className="w-48 h-28 bg-slate-800 rounded-xl border border-slate-700 shadow-xl flex items-center justify-center text-xs text-slate-300">
                  YouTube App
                </div>
                <div className="w-44 h-20 bg-slate-800/70 rounded-xl border border-slate-700/60 shadow-lg flex items-center justify-center text-xs text-slate-400">
                  Chrome
                </div>
              </div>
            ) : (
              <div className="w-full h-full bg-slate-900 text-white p-3 flex flex-col gap-2">
                <div className="bg-slate-800 p-2 rounded-lg text-xs font-mono text-cyan-300">
                  Google Search Active
                </div>
                <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                  <p className="text-xs font-bold text-cyan-400">Garena Free Fire: 6th Anniversary</p>
                  <p className="text-[10px] text-slate-300 mt-1">
                    Battle in 10-minute matches on mobile. Free to download on Google Play Store.
                  </p>
                </div>
              </div>
            )}

            {/* Assistant Floating Bottom Sheet Interface */}
            <div className="mt-auto bg-slate-950/95 backdrop-blur-xl border-t border-slate-800 p-3 flex flex-col gap-2 rounded-t-3xl shadow-2xl z-20">
              {/* Sheet Header: AI Assistant + Status + Action icons */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-1.5">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span className="text-xs font-bold text-white tracking-wide">AI Assistant</span>
                  <span className="bg-slate-800/90 text-cyan-400 border border-cyan-800/40 text-[9px] px-1.5 py-0.5 rounded-full font-mono font-semibold">
                    {status}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={onNewConversation}
                    title="New conversation"
                    className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setShowSettingsView(!showSettingsView)}
                    title="Settings"
                    className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  >
                    <SettingsIcon className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Voice recognition & Response bubble */}
              {recognizedText && (
                <div className="bg-slate-900/90 rounded-xl p-2 px-2.5 border border-slate-800 text-[11px] flex items-center gap-2">
                  <span className="text-cyan-400 font-bold">🗣️</span>
                  <span className="text-slate-100 font-medium">You: "{recognizedText}"</span>
                </div>
              )}

              {assistantResponse && (
                <div className="bg-cyan-950/50 rounded-xl p-2 px-2.5 border border-cyan-800/60 text-[11px] flex items-start gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
                  <span className="text-cyan-200">AI: {assistantResponse}</span>
                </div>
              )}

              {/* Strict Safety Confirmation Modal inside Phone (Section 10) */}
              {safetyPrompt && (
                <div className="p-2.5 bg-amber-950/90 border border-amber-600/80 rounded-2xl flex flex-col gap-1.5 shadow-lg animate-fadeIn">
                  <div className="flex items-center gap-1.5 text-amber-400 text-xs font-bold">
                    <ShieldAlert className="w-4 h-4" />
                    <span>Confirmation Required</span>
                  </div>
                  <p className="text-[11px] text-amber-200 leading-tight">
                    {safetyPrompt}
                  </p>
                  <div className="flex gap-2 mt-1">
                    <button
                      onClick={() => onConfirmSafety(false)}
                      className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold py-1 rounded-lg transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => onConfirmSafety(true)}
                      className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold py-1 rounded-lg transition-colors"
                    >
                      Confirm
                    </button>
                  </div>
                </div>
              )}

              {/* Centerpiece: Big Microphone + Text Input Bar */}
              <div className="flex items-center gap-2 pt-1">
                {/* Text input with send button */}
                <div className="flex-1 flex items-center bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 focus-within:border-cyan-500">
                  <input
                    type="text"
                    value={typedInput}
                    onChange={(e) => setTypedInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Command type karein..."
                    className="w-full bg-transparent text-xs text-white placeholder-slate-500 outline-none"
                  />
                  <button
                    onClick={handleSend}
                    disabled={!typedInput.trim()}
                    className="p-1 text-cyan-400 disabled:text-slate-600 hover:text-cyan-300 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Big Mic Button */}
                <button
                  id="assistant-mic-button"
                  onClick={onMicClick}
                  className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 transition-all duration-300 shadow-lg active:scale-90 ${
                    status === 'LISTENING'
                      ? 'bg-red-500 animate-pulse ring-4 ring-red-500/40 text-white'
                      : status === 'SPEAKING'
                      ? 'bg-emerald-500 ring-4 ring-emerald-500/30 text-white'
                      : 'bg-cyan-600 hover:bg-cyan-500 text-white'
                  }`}
                  title="Speak Hindi/Hinglish command"
                >
                  <Mic className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Android Navigation Bar (Back, Home, Recents) */}
          <div className="h-9 px-8 flex justify-around items-center text-slate-400 bg-black/40 rounded-b-[40px]">
            <button
              onClick={() => onNavAction('BACK')}
              className="p-1 hover:text-white transition-colors"
              title="Back button"
            >
              <Triangle className="w-3.5 h-3.5 -rotate-90 fill-current" />
            </button>
            <button
              onClick={() => onNavAction('HOME')}
              className="p-1 hover:text-white transition-colors"
              title="Home button"
            >
              <Circle className="w-3.5 h-3.5 fill-current" />
            </button>
            <button
              onClick={() => onNavAction('RECENTS')}
              className="p-1 hover:text-white transition-colors"
              title="Recent apps button"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
            </button>
          </div>
        </div>
      </div>

      {/* Side Control & Verification Panel */}
      <div className="flex-1 max-w-xl flex flex-col gap-4">
        {/* Tab switcher */}
        <div className="flex items-center justify-between bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800">
          <div className="flex gap-1">
            <button
              onClick={() => setActiveTab('interactive')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'interactive'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Quick Test Commands
            </button>
            <button
              onClick={() => setActiveTab('logs')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'logs'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Command History</span>
              <span className="bg-slate-800 px-1.5 py-0.5 rounded-full text-[10px] text-cyan-300 font-mono">
                {history.length}
              </span>
            </button>
          </div>

          <button
            onClick={() => setShowWelcomeModal(true)}
            className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 px-2 py-1"
          >
            <Info className="w-3.5 h-3.5" />
            <span>Welcome Modal</span>
          </button>
        </div>

        {activeTab === 'interactive' ? (
          <div className="flex flex-col gap-4">
            {/* Quick Test Chips */}
            <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 tracking-wide">
                  CLICK TO TEST NATURAL COMMANDS:
                </span>
                <span className="text-[10px] text-slate-500">Hindi / Hinglish</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {sampleCommands.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => onSendCommandText(item.cmd)}
                    className="bg-slate-800/90 hover:bg-cyan-900/40 hover:border-cyan-500/50 border border-slate-700/60 text-slate-200 text-xs px-3 py-1.5 rounded-xl transition-all active:scale-95 text-left"
                  >
                    "{item.cmd}"
                  </button>
                ))}
              </div>
            </div>

            {/* Verification checklist card */}
            <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-3">
              <span className="text-xs font-bold text-slate-200 tracking-wide">
                NATIVE ARCHITECTURE VERIFICATION
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="flex items-start gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="font-semibold text-slate-200">Hindi / Hinglish NLU</p>
                    <p className="text-[11px] text-slate-400">Regex + intent aliases without hardcoded small lists.</p>
                  </div>
                </div>

                <div className="flex items-start gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="font-semibold text-slate-200">Accessibility Service</p>
                    <p className="text-[11px] text-slate-400">Controls Back, Home, Recents, Click, and Scroll.</p>
                  </div>
                </div>

                <div className="flex items-start gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="font-semibold text-slate-200">Safety Confirmation</p>
                    <p className="text-[11px] text-slate-400">Guards sensitive messaging, payments & delete.</p>
                  </div>
                </div>

                <div className="flex items-start gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="font-semibold text-slate-200">Graceful Uninstalled App</p>
                    <p className="text-[11px] text-slate-400">"Ye app aapke phone mein installed nahi hai."</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Command History Logs */
          <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 tracking-wide">
                SAVED CONVERSATION HISTORY
              </span>
              {history.length > 0 && (
                <button
                  onClick={onClearHistory}
                  className="text-red-400 hover:text-red-300 text-[11px] font-semibold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear All</span>
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs">
                Koi conversation history nahi hai. Command bolkar ya type karke shuru karein.
              </div>
            ) : (
              <div className="flex flex-col gap-2 max-h-[480px] overflow-y-auto pr-1">
                {history.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 flex flex-col gap-1 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-200">You: "{item.command}"</span>
                      <button
                        onClick={() => onDeleteHistoryItem(item.id)}
                        className="text-slate-500 hover:text-red-400 p-0.5"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-cyan-400 font-medium">AI: {item.responseHindi}</p>
                    <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-800/60 mt-1">
                      <span className="font-mono">{item.intent}</span>
                      <span>{item.timestamp}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Welcome Dialog Modal (Section 22) */}
      {showWelcomeModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-sm w-full shadow-2xl flex flex-col gap-4 animate-scaleUp">
            <div>
              <h3 className="text-lg font-bold text-cyan-400">Namaste 👋</h3>
              <p className="text-base font-semibold text-white">Main aapka AI Assistant hoon.</p>
            </div>

            <div className="flex flex-col gap-2.5 text-xs text-slate-300">
              <p>• Aap bolkar ya type karke natural Hindi/Hinglish commands de sakte hain.</p>
              <p>• Phone screen control, clicking aur scrolling ke liye Accessibility Service chalu hona zaroori hai.</p>
              <p>• Permissions aur voice preferences Settings screen se badal sakte hain.</p>
            </div>

            <button
              onClick={() => setShowWelcomeModal(false)}
              className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-2.5 rounded-xl text-sm transition-colors mt-2"
            >
              Shuru Karein (Get Started)
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
