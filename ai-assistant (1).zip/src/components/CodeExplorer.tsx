import React, { useState } from 'react';
import { Copy, Check, FileCode, Folder, Code } from 'lucide-react';
import { ANDROID_FILES } from '../androidProjectFiles';

interface CodeExplorerProps {
  files?: typeof ANDROID_FILES;
  onDownloadZip?: () => void;
}

export const CodeExplorer: React.FC<CodeExplorerProps> = ({ files = ANDROID_FILES, onDownloadZip }) => {
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  const currentFile = files[selectedFileIndex] || files[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col md:flex-row h-[680px]">
      {/* File Tree Sidebar */}
      <div className="w-full md:w-80 bg-slate-950/80 border-r border-slate-800 flex flex-col">
        <div className="p-3 border-b border-slate-800 flex items-center gap-2">
          <Folder className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Native Android Source
          </span>
        </div>

        <div className="flex-1 overflow-y-auto p-2 flex flex-col gap-1">
          {files.map((file, idx) => (
            <button
              key={file.path}
              onClick={() => setSelectedFileIndex(idx)}
              className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center gap-2 transition-all ${
                selectedFileIndex === idx
                  ? 'bg-cyan-950/70 border border-cyan-700/60 text-cyan-200 font-medium'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <FileCode className="w-3.5 h-3.5 shrink-0 text-cyan-400" />
              <div className="flex flex-col truncate">
                <span className="truncate">{file.path.split('/').pop()}</span>
                <span className="text-[10px] text-slate-500 truncate">{file.path}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Code Viewer */}
      <div className="flex-1 flex flex-col bg-slate-950">
        <div className="p-3 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
          <div className="flex items-center gap-2">
            <Code className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-mono text-slate-300">{currentFile.path}</span>
            <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">
              {currentFile.category}
            </span>
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy File'}</span>
          </button>
        </div>

        <div className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-300 leading-relaxed select-text">
          <pre>
            <code>{currentFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
