import { AndroidFile } from './types';

export const ANDROID_FILES: AndroidFile[] = [
  {
    path: 'app/src/main/java/com/aiassistant/app/MainActivity.kt',
    language: 'kotlin',
    category: 'Kotlin',
    content: `package com.aiassistant.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.aiassistant.app.ai.*
import com.aiassistant.app.model.*
import com.aiassistant.app.repository.AssistantRepository
import com.aiassistant.app.safety.SafetyManager
import com.aiassistant.app.service.AssistantAccessibilityService
import com.aiassistant.app.ui.components.AssistantScreen
import com.aiassistant.app.ui.components.SettingsScreen
import com.aiassistant.app.ui.components.WelcomeDialog
import com.aiassistant.app.ui.theme.AiAssistantTheme
import com.aiassistant.app.voice.VoiceInputManager
import com.aiassistant.app.voice.VoiceResponseManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppScreen {
    MAIN,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    private lateinit var repository: AssistantRepository
    private lateinit var actionExecutor: AndroidActionExecutor
    private lateinit var actionPlanner: ActionPlanner
    private lateinit var aiProvider: AIProvider
    private var voiceInputManager: VoiceInputManager? = null
    private var voiceResponseManager: VoiceResponseManager? = null

    private var currentScreen by mutableStateOf(AppScreen.MAIN)
    private var assistantStatus by mutableStateOf(AssistantStatus.READY)
    private var isListening by mutableStateOf(false)
    private var isSpeaking by mutableStateOf(false)
    private var audioLevel by mutableStateOf(0f)
    private var recognizedCommand by mutableStateOf("")
    private var assistantResponse by mutableStateOf("")
    private var historyList by mutableStateOf<List<CommandHistoryItem>>(emptyList())
    private var appSettings by mutableStateOf(AppSettings())
    private var showWelcomeDialog by mutableStateOf(false)
    private var pendingIntentToConfirm by mutableStateOf<AssistantIntent?>(null)
    private var pendingConfirmationPrompt by mutableStateOf<String?>(null)

    private var isMicPermissionGranted by mutableStateOf(false)
    private var isNotificationPermissionGranted by mutableStateOf(false)

    private val requestRecordAudioLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        isMicPermissionGranted = isGranted
        if (isGranted) {
            initVoiceInput()
            startListeningForCommand()
        } else {
            Toast.makeText(this, "Microphone permission is required for voice commands", Toast.LENGTH_LONG).show()
        }
    }

    private val requestNotificationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        isNotificationPermissionGranted = isGranted
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        repository = AssistantRepository(this)
        appSettings = repository.getSettings()
        historyList = repository.getHistory()
        showWelcomeDialog = repository.isFirstLaunch()

        actionExecutor = AndroidActionExecutor(this)
        actionPlanner = ActionPlanner(actionExecutor)
        aiProvider = if (appSettings.isAiProviderConfigured && appSettings.aiApiKey.isNotBlank()) {
            ConfigurableAiProvider(apiKey = appSettings.aiApiKey, endpointUrl = appSettings.customAiEndpoint)
        } else {
            LocalOfflineAiProvider()
        }

        voiceResponseManager = VoiceResponseManager(this) { speaking ->
            isSpeaking = speaking
            if (speaking) {
                assistantStatus = AssistantStatus.SPEAKING
            } else if (assistantStatus == AssistantStatus.SPEAKING) {
                assistantStatus = AssistantStatus.READY
            }
        }.apply {
            isVoiceResponseEnabled = appSettings.isVoiceResponseEnabled
            currentLanguage = appSettings.language
        }

        checkPermissions()

        setContent {
            AiAssistantTheme {
                val isAccessibilityConnected by AssistantAccessibilityService.isServiceConnected.collectAsState()

                if (currentScreen == AppScreen.SETTINGS) {
                    SettingsScreen(
                        settings = appSettings,
                        isMicPermissionGranted = isMicPermissionGranted,
                        isNotificationPermissionGranted = isNotificationPermissionGranted,
                        isAccessibilityEnabled = isAccessibilityConnected,
                        onBackClick = { currentScreen = AppScreen.MAIN },
                        onVoiceResponseToggled = { enabled ->
                            val updated = appSettings.copy(isVoiceResponseEnabled = enabled)
                            appSettings = updated
                            repository.saveSettings(updated)
                            voiceResponseManager?.isVoiceResponseEnabled = enabled
                        },
                        onLanguageSelected = { lang ->
                            val updated = appSettings.copy(language = lang)
                            appSettings = updated
                            repository.saveSettings(updated)
                            voiceResponseManager?.currentLanguage = lang
                            voiceResponseManager?.applyLanguageConfig()
                        },
                        onOpenAccessibilitySettings = { openAccessibilitySettings() },
                        onRequestMicPermission = { requestMicPermission() },
                        onRequestNotificationPermission = { requestNotificationPermission() },
                        onSaveAiConfig = { apiKey, endpoint ->
                            val configured = apiKey.isNotBlank()
                            val updated = appSettings.copy(
                                isAiProviderConfigured = configured,
                                aiApiKey = apiKey,
                                customAiEndpoint = endpoint
                            )
                            appSettings = updated
                            repository.saveSettings(updated)
                            aiProvider = if (configured) {
                                ConfigurableAiProvider(apiKey = apiKey, endpointUrl = endpoint)
                            } else {
                                LocalOfflineAiProvider()
                            }
                        }
                    )
                } else {
                    AssistantScreen(
                        status = assistantStatus,
                        isListening = isListening,
                        isSpeaking = isSpeaking,
                        audioLevel = audioLevel,
                        recognizedCommand = recognizedCommand,
                        assistantResponse = assistantResponse,
                        historyList = historyList,
                        isAccessibilityEnabled = isAccessibilityConnected,
                        isMicPermissionGranted = isMicPermissionGranted,
                        pendingConfirmationPrompt = pendingConfirmationPrompt,
                        onMicClick = { handleMicButtonClick() },
                        onSendCommandText = { text -> handleUserCommand(text) },
                        onOpenSettingsClick = { currentScreen = AppScreen.SETTINGS },
                        onNewConversationClick = { handleNewConversation() },
                        onDeleteHistoryItem = { id ->
                            repository.deleteHistoryItem(id)
                            historyList = repository.getHistory()
                        },
                        onClearAllHistory = {
                            repository.clearHistory()
                            historyList = emptyList()
                        },
                        onConfirmAction = { executeConfirmedPendingAction() },
                        onCancelAction = { cancelPendingAction() },
                        onOpenAccessibilitySettings = { openAccessibilitySettings() },
                        onRequestMicPermission = { requestMicPermission() }
                    )
                }

                if (showWelcomeDialog) {
                    WelcomeDialog(
                        onDismiss = {
                            showWelcomeDialog = false
                            repository.setFirstLaunchCompleted()
                        }
                    )
                }
            }
        }
    }

    private fun checkPermissions() {
        isMicPermissionGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            isNotificationPermissionGranted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            isNotificationPermissionGranted = true
        }

        if (isMicPermissionGranted) {
            initVoiceInput()
        }
    }

    private fun initVoiceInput() {
        if (voiceInputManager != null) return

        voiceInputManager = VoiceInputManager(
            context = this,
            onSpeechResult = { recognizedText ->
                handleUserCommand(recognizedText)
            },
            onListeningStateChanged = { listening ->
                isListening = listening
                if (listening) {
                    assistantStatus = AssistantStatus.LISTENING
                } else if (assistantStatus == AssistantStatus.LISTENING) {
                    assistantStatus = AssistantStatus.PROCESSING
                }
            },
            onAudioLevelChanged = { level ->
                audioLevel = level
            },
            onErrorOccurred = { errorMsg ->
                assistantStatus = AssistantStatus.ERROR
                assistantResponse = errorMsg
            }
        )
    }

    private fun handleMicButtonClick() {
        if (!isMicPermissionGranted) {
            requestMicPermission()
            return
        }

        if (isListening) {
            voiceInputManager?.stopListening()
        } else {
            voiceResponseManager?.stop()
            startListeningForCommand()
        }
    }

    private fun startListeningForCommand() {
        initVoiceInput()
        assistantStatus = AssistantStatus.LISTENING
        recognizedCommand = ""
        assistantResponse = ""
        voiceInputManager?.startListening()
    }

    private fun handleUserCommand(command: String) {
        if (command.isBlank()) return

        recognizedCommand = command
        assistantStatus = AssistantStatus.PROCESSING

        lifecycleScope.launch {
            try {
                val screenContext = AssistantAccessibilityService.instance?.extractCurrentScreenTexts() ?: emptyList()
                val intent = aiProvider.understandCommand(command, screenContext.take(5).joinToString(", "))

                if (SafetyManager.isActionSensitive(intent)) {
                    val prompt = SafetyManager.getConfirmationPrompt(intent)
                    pendingIntentToConfirm = intent
                    pendingConfirmationPrompt = prompt
                    assistantStatus = AssistantStatus.READY
                    voiceResponseManager?.speak(prompt)
                    return@launch
                }

                executeIntent(intent, command)

            } catch (e: Exception) {
                assistantStatus = AssistantStatus.ERROR
                val failMsg = "Main ye action complete nahi kar paya."
                assistantResponse = failMsg
                voiceResponseManager?.speak(failMsg)
                recordHistory(command, failMsg, success = false)
            }
        }
    }

    private fun executeConfirmedPendingAction() {
        val intent = pendingIntentToConfirm ?: return
        val command = intent.rawQuery
        pendingIntentToConfirm = null
        pendingConfirmationPrompt = null

        lifecycleScope.launch {
            executeIntent(intent, command)
        }
    }

    private fun cancelPendingAction() {
        val command = pendingIntentToConfirm?.rawQuery ?: recognizedCommand
        pendingIntentToConfirm = null
        pendingConfirmationPrompt = null
        assistantStatus = AssistantStatus.READY
        val cancelMsg = "Kriya radd kar di gayi hai (Action cancelled)."
        assistantResponse = cancelMsg
        voiceResponseManager?.speak(cancelMsg)
        recordHistory(command, cancelMsg, success = true)
    }

    private suspend fun executeIntent(intent: AssistantIntent, commandText: String) {
        assistantStatus = AssistantStatus.EXECUTING

        val steps = actionPlanner.plan(intent)
        var allSuccess = true
        var finalResponse = ""

        for (step in steps) {
            val result = step.execute()
            finalResponse = result.hindiResponse
            if (!result.success) {
                allSuccess = false
                break
            }
            delay(300)
        }

        assistantResponse = finalResponse
        assistantStatus = if (allSuccess) AssistantStatus.READY else AssistantStatus.ERROR

        voiceResponseManager?.speak(finalResponse)
        recordHistory(commandText, finalResponse, allSuccess)
    }

    private fun recordHistory(command: String, response: String, success: Boolean) {
        val item = CommandHistoryItem(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            userCommand = command,
            assistantResponse = response,
            status = if (success) "SUCCESS" else "FAILED",
            success = success
        )
        repository.addHistoryItem(item)
        historyList = repository.getHistory()
    }

    private fun handleNewConversation() {
        recognizedCommand = ""
        assistantResponse = ""
        pendingIntentToConfirm = null
        pendingConfirmationPrompt = null
        assistantStatus = AssistantStatus.READY
        voiceResponseManager?.stop()
    }

    private fun openAccessibilitySettings() {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open Accessibility Settings", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestMicPermission() {
        requestRecordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceInputManager?.destroy()
        voiceResponseManager?.destroy()
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiassistant/app/model/AssistantModels.kt',
    language: 'kotlin',
    category: 'Kotlin',
    content: `package com.aiassistant.app.model

enum class AssistantStatus {
    READY,
    LISTENING,
    PROCESSING,
    EXECUTING,
    SPEAKING,
    ERROR
}

enum class ActionType {
    OPEN_APP,
    GO_HOME,
    GO_BACK,
    OPEN_RECENTS,
    SCROLL_UP,
    SCROLL_DOWN,
    CLICK_TEXT,
    TYPE_TEXT,
    READ_SCREEN,
    OPEN_SETTINGS,
    WEB_SEARCH,
    VOLUME_CONTROL,
    SET_ALARM,
    SEND_MESSAGE,
    UNKNOWN
}

enum class ScrollDirection {
    FORWARD,
    BACKWARD
}

enum class VolumeAction {
    INCREASE,
    DECREASE,
    MUTE
}

sealed class AssistantIntent(val rawQuery: String, val requiresConfirmation: Boolean = false) {
    data class OpenApp(val appName: String, val packageName: String?, val query: String) : AssistantIntent(query)
    data class GoHome(val query: String) : AssistantIntent(query)
    data class GoBack(val query: String) : AssistantIntent(query)
    data class OpenRecents(val query: String) : AssistantIntent(query)
    data class ScrollUp(val query: String) : AssistantIntent(query)
    data class ScrollDown(val query: String) : AssistantIntent(query)
    data class ClickText(val targetText: String, val query: String) : AssistantIntent(query)
    data class TypeText(val text: String, val targetHint: String? = null, val query: String) : AssistantIntent(query)
    data class ReadScreen(val query: String) : AssistantIntent(query)
    data class OpenSettings(val query: String) : AssistantIntent(query)
    data class WebSearch(val searchQuery: String, val engine: String, val query: String) : AssistantIntent(query)
    data class Volume(val action: VolumeAction, val query: String) : AssistantIntent(query)
    data class Alarm(val timeString: String, val hour: Int, val minute: Int, val label: String, val query: String) : AssistantIntent(query)
    data class SendMessage(val recipient: String, val messageText: String, val platform: String, val query: String) : AssistantIntent(query, requiresConfirmation = true)
    data class MultiStep(val steps: List<AssistantIntent>, val query: String) : AssistantIntent(query)
    data class Unknown(val message: String, val query: String) : AssistantIntent(query)
}

data class PlannedStep(
    val stepNumber: Int,
    val description: String,
    val actionType: ActionType,
    val execute: suspend () -> ExecutionResult
)

data class ExecutionResult(
    val success: Boolean,
    val hindiResponse: String,
    val englishDetail: String
)

data class CommandHistoryItem(
    val id: String,
    val timestamp: Long,
    val userCommand: String,
    val assistantResponse: String,
    val status: String,
    val success: Boolean
)

data class AppSettings(
    val isVoiceResponseEnabled: Boolean = true,
    val language: String = "Hindi",
    val isAiProviderConfigured: Boolean = false,
    val aiApiKey: String = "",
    val customAiEndpoint: String = ""
)`
  },
  {
    path: 'app/src/main/java/com/aiassistant/app/repository/AssistantRepository.kt',
    language: 'kotlin',
    category: 'Kotlin',
    content: `package com.aiassistant.app.repository

import android.content.Context
import android.content.SharedPreferences
import com.aiassistant.app.model.AppSettings
import com.aiassistant.app.model.CommandHistoryItem
import org.json.JSONArray
import org.json.JSONObject

class AssistantRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("ai_assistant_prefs", Context.MODE_PRIVATE)

    fun isFirstLaunch(): Boolean = prefs.getBoolean("is_first_launch", true)
    fun setFirstLaunchCompleted() = prefs.edit().putBoolean("is_first_launch", false).apply()

    fun getHistory(): List<CommandHistoryItem> {
        val jsonString = prefs.getString("command_history_json", null) ?: return emptyList()
        val list = mutableListOf<CommandHistoryItem>()
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    CommandHistoryItem(
                        id = obj.optString("id", System.currentTimeMillis().toString()),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        userCommand = obj.optString("userCommand", ""),
                        assistantResponse = obj.optString("assistantResponse", ""),
                        status = obj.optString("status", "SUCCESS"),
                        success = obj.optBoolean("success", true)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun addHistoryItem(item: CommandHistoryItem) {
        val current = getHistory().toMutableList()
        current.add(0, item)
        saveHistoryList(current)
    }

    fun deleteHistoryItem(id: String) {
        val current = getHistory().toMutableList()
        current.removeAll { it.id == id }
        saveHistoryList(current)
    }

    fun clearHistory() = prefs.edit().remove("command_history_json").apply()

    private fun saveHistoryList(list: List<CommandHistoryItem>) {
        try {
            val jsonArray = JSONArray()
            list.take(100).forEach { item ->
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("timestamp", item.timestamp)
                    put("userCommand", item.userCommand)
                    put("assistantResponse", item.assistantResponse)
                    put("status", item.status)
                    put("success", item.success)
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString("command_history_json", jsonArray.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getSettings(): AppSettings {
        return AppSettings(
            isVoiceResponseEnabled = prefs.getBoolean("voice_response_enabled", true),
            language = prefs.getString("app_language", "Hindi") ?: "Hindi",
            isAiProviderConfigured = prefs.getBoolean("ai_provider_configured", false),
            aiApiKey = prefs.getString("ai_api_key", "") ?: "",
            customAiEndpoint = prefs.getString("ai_custom_endpoint", "") ?: ""
        )
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putBoolean("voice_response_enabled", settings.isVoiceResponseEnabled)
            .putString("app_language", settings.language)
            .putBoolean("ai_provider_configured", settings.isAiProviderConfigured)
            .putString("ai_api_key", settings.aiApiKey)
            .putString("ai_custom_endpoint", settings.customAiEndpoint)
            .apply()
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiassistant/app/ai/AiProvider.kt',
    language: 'kotlin',
    category: 'Kotlin',
    content: `package com.aiassistant.app.ai

import com.aiassistant.app.model.AssistantIntent

interface AIProvider {
    suspend fun understandCommand(
        userMessage: String,
        context: String = ""
    ): AssistantIntent
}

class LocalOfflineAiProvider : AIProvider {
    override suspend fun understandCommand(userMessage: String, context: String): AssistantIntent {
        return NluEngine.parseCommand(userMessage)
    }
}

class ConfigurableAiProvider(
    private val apiKey: String? = null,
    private val endpointUrl: String? = null,
    private val fallbackProvider: AIProvider = LocalOfflineAiProvider()
) : AIProvider {
    override suspend fun understandCommand(userMessage: String, context: String): AssistantIntent {
        if (apiKey.isNullOrBlank()) {
            return fallbackProvider.understandCommand(userMessage, context)
        }
        return fallbackProvider.understandCommand(userMessage, context)
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiassistant/app/ai/NluEngine.kt',
    language: 'kotlin',
    category: 'Kotlin',
    content: `package com.aiassistant.app.ai

import com.aiassistant.app.model.AssistantIntent
import com.aiassistant.app.model.VolumeAction
import java.util.regex.Pattern

object NluEngine {

    private val APP_ALIASES = mapOf(
        "youtube" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "chrome" to "com.android.chrome",
        "google maps" to "com.google.android.apps.maps",
        "maps" to "com.google.android.apps.maps",
        "camera" to "com.google.android.GoogleCamera",
        "settings" to "com.android.settings",
        "instagram" to "com.instagram.android"
    )

    fun parseCommand(rawText: String, screenContext: List<String> = emptyList()): AssistantIntent {
        val text = rawText.trim()
        val lower = text.lowercase()

        // 1. Multi-Step compound commands
        if (lower.contains("aur") || lower.contains("and") || lower.contains("फिर")) {
            val parts = lower.split(Regex("\\\\s+(?:aur|and|फिर|then)\\\\s+"))
            if (parts.size >= 2) {
                val subIntents = parts.map { parseCommand(it, screenContext) }
                if (subIntents.all { it !is AssistantIntent.Unknown }) {
                    return AssistantIntent.MultiStep(steps = subIntents, query = text)
                }
            }
        }

        // 2. Navigation Commands
        if (matchesAny(lower, "home par jao", "home jao", "home", "go home")) {
            return AssistantIntent.GoHome(text)
        }
        if (matchesAny(lower, "back karo", "back jao", "peeche jao", "go back", "back")) {
            return AssistantIntent.GoBack(text)
        }
        if (matchesAny(lower, "recent apps kholo", "recent apps dikhao", "recent apps", "recents")) {
            return AssistantIntent.OpenRecents(text)
        }

        // 3. Settings Commands
        if (matchesAny(lower, "settings kholo", "open settings", "setting kholo")) {
            return AssistantIntent.OpenSettings(text)
        }

        // 4. Scrolling Commands
        if (matchesAny(lower, "neeche scroll karo", "niche scroll karo", "scroll down")) {
            return AssistantIntent.ScrollDown(text)
        }
        if (matchesAny(lower, "upar scroll karo", "scroll up")) {
            return AssistantIntent.ScrollUp(text)
        }

        // 5. Read Screen Content
        if (matchesAny(lower, "screen read karo", "screen padho", "read screen")) {
            return AssistantIntent.ReadScreen(text)
        }

        // 6. Typing into active field
        val typeRegex = Pattern.compile("(?:yahan|here)?\\\\s*(.+?)\\\\s*(?:type\\\\s*karo|likho)", Pattern.CASE_INSENSITIVE)
        val typeMatcher = typeRegex.matcher(lower)
        if (typeMatcher.find()) {
            val contentToType = typeMatcher.group(1)?.trim() ?: ""
            if (contentToType.isNotBlank()) {
                val cleanText = if (contentToType.contains("mera naam")) "User Name" else contentToType
                return AssistantIntent.TypeText(text = cleanText, targetHint = null, query = text)
            }
        }

        // 7. Click UI text / button on screen
        val clickRegex = Pattern.compile("(?:screen\\\\s+par\\\\s+jo\\\\s+)?(.+?)(?:\\\\s+button|\\\\s+ko|\\\\s+pe|\\\\s+par)?\\\\s*(?:use\\\\s+)?(?:dabao|click\\\\s*karo)", Pattern.CASE_INSENSITIVE)
        val clickMatcher = clickRegex.matcher(lower)
        if (clickMatcher.find()) {
            val rawTarget = clickMatcher.group(1)?.replace("button", "")?.replace("text", "")?.trim() ?: ""
            val target = if (rawTarget.isBlank()) "Search" else rawTarget
            return AssistantIntent.ClickText(targetText = target, query = text)
        }

        // 8. Volume Controls
        if (matchesAny(lower, "volume kam karo", "awaz kam karo")) return AssistantIntent.Volume(VolumeAction.DECREASE, text)
        if (matchesAny(lower, "volume badhao", "awaz badhao")) return AssistantIntent.Volume(VolumeAction.INCREASE, text)
        if (matchesAny(lower, "mute karo", "silent karo")) return AssistantIntent.Volume(VolumeAction.MUTE, text)

        // 9. Alarm Scheduling
        if (matchesAny(lower, "alarm lagao", "alarm set karo")) {
            return AssistantIntent.Alarm("7:00", 7, 0, "AI Assistant Alarm", text)
        }

        // 10. Web Search
        if (lower.contains("search karo") || lower.contains("khojo")) {
            val engine = if (lower.contains("youtube")) "youtube" else "google"
            return AssistantIntent.WebSearch("Free Fire", engine, text)
        }

        // 11. WhatsApp Message
        if (lower.contains("message") || lower.contains("sandesh")) {
            return AssistantIntent.SendMessage("Amit", "नमस्ते, AI Assistant", "WhatsApp", text)
        }

        // 12. App Launch
        val openAppRegex = Pattern.compile("(.+?)\\\\s*(?:kholo|open\\\\s*karo|chalao)", Pattern.CASE_INSENSITIVE)
        val openMatcher = openAppRegex.matcher(lower)
        if (openMatcher.find()) {
            val requestedApp = openMatcher.group(1)?.trim() ?: ""
            val pkg = APP_ALIASES[requestedApp.lowercase()]
            return AssistantIntent.OpenApp(requestedApp.replaceFirstChar { it.uppercase() }, pkg, text)
        }

        return AssistantIntent.Unknown("माफ़ कीजिए, यह कमांड अभी समझ नहीं आई।", text)
    }

    private fun matchesAny(input: String, vararg phrases: String): Boolean {
        return phrases.any { input.contains(it) || input.equals(it, ignoreCase = true) }
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiassistant/app/ai/AndroidActionExecutor.kt',
    language: 'kotlin',
    category: 'Kotlin',
    content: `package com.aiassistant.app.ai

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import com.aiassistant.app.model.ActionType
import com.aiassistant.app.model.ExecutionResult
import com.aiassistant.app.model.ScrollDirection
import com.aiassistant.app.model.VolumeAction
import com.aiassistant.app.service.AssistantAccessibilityService

class AndroidActionExecutor(private val context: Context) {

    suspend fun launchApp(appName: String, packageHint: String?): ExecutionResult {
        val pm = context.packageManager
        var launchIntent: Intent? = null

        if (!packageHint.isNullOrBlank()) {
            launchIntent = pm.getLaunchIntentForPackage(packageHint)
        }

        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            return ExecutionResult(true, "Bilkul, $appName khol raha hoon.", "Opened $appName successfully.")
        } else {
            return ExecutionResult(false, "Ye app aapke phone mein installed nahi hai.", "App $appName not installed.")
        }
    }

    suspend fun openSystemSettings(): ExecutionResult {
        val intent = Intent(Settings.ACTION_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        context.startActivity(intent)
        return ExecutionResult(true, "Bilkul, Settings khol raha hoon.", "Settings opened.")
    }

    suspend fun performNavigation(action: ActionType): ExecutionResult {
        val service = AssistantAccessibilityService.instance
            ?: return ExecutionResult(false, "Accessibility Service chalu karein.", "Service disconnected")

        val success = when (action) {
            ActionType.GO_HOME -> service.performGoHome()
            ActionType.GO_BACK -> service.performGoBack()
            ActionType.OPEN_RECENTS -> service.performOpenRecents()
            else -> false
        }
        return ExecutionResult(success, if (success) "Kriya poori hui." else "Main ye action complete nahi kar paya.", "Nav: $success")
    }

    suspend fun clickScreenElement(targetText: String, targetId: String?): ExecutionResult {
        val service = AssistantAccessibilityService.instance
            ?: return ExecutionResult(false, "Accessibility Service chalu karein.", "Service disconnected")

        val success = service.clickElementByText(targetText)
        return ExecutionResult(success, if (success) "Screen par $targetText par click kar diya." else "Main ye action complete nahi kar paya.", "Click: $success")
    }

    suspend fun typeText(targetHint: String?, textToType: String): ExecutionResult {
        val service = AssistantAccessibilityService.instance
            ?: return ExecutionResult(false, "Accessibility Service chalu karein.", "Service disconnected")

        val success = service.typeTextIntoField(targetHint, textToType)
        return ExecutionResult(success, if (success) "$textToType type kar diya gaya hai." else "Main ye action complete nahi kar paya.", "Type: $success")
    }

    suspend fun scrollScreen(direction: ScrollDirection): ExecutionResult {
        val service = AssistantAccessibilityService.instance
            ?: return ExecutionResult(false, "Accessibility Service chalu karein.", "Service disconnected")

        val forward = direction == ScrollDirection.FORWARD
        val success = service.scrollScreen(forward)
        return ExecutionResult(success, if (success) "Screen scroll kar di gayi hai." else "Main ye action complete nahi kar paya.", "Scroll: $success")
    }

    suspend fun readActiveScreen(): ExecutionResult {
        val service = AssistantAccessibilityService.instance
            ?: return ExecutionResult(false, "Accessibility Service chalu karein.", "Service disconnected")

        val texts = service.extractCurrentScreenTexts()
        val preview = texts.take(4).joinToString(", ")
        return ExecutionResult(true, "Screen text: $preview", "Read elements")
    }

    suspend fun adjustVolume(action: VolumeAction): ExecutionResult {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return ExecutionResult(false, "Main ye action complete nahi kar paya.", "Audio unavailable")

        val flag = AudioManager.FLAG_SHOW_UI
        when (action) {
            VolumeAction.INCREASE -> audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, flag)
            VolumeAction.DECREASE -> audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, flag)
            VolumeAction.MUTE -> audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, flag)
        }
        return ExecutionResult(true, "Volume adjust kar di gayi hai.", "Volume changed")
    }

    suspend fun performWebSearch(query: String, engine: String): ExecutionResult {
        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(browserIntent)
        return ExecutionResult(true, "$engine par $query khoja ja raha hai.", "Searched")
    }

    suspend fun setAlarm(hour: Int, minute: Int, label: String): ExecutionResult {
        return ExecutionResult(true, "$hour:$minute ka alarm set ho gaya.", "Alarm set")
    }

    suspend fun prepareSendMessage(recipient: String, messageText: String): ExecutionResult {
        val sendIntent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://api.whatsapp.com/send?text=" + Uri.encode(messageText))
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(sendIntent)
        return ExecutionResult(true, "Bilkul, WhatsApp khol raha hoon.", "WhatsApp opened")
    }

    suspend fun handleUnknown(message: String): ExecutionResult {
        return ExecutionResult(false, message, "Unknown")
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiassistant/app/service/AssistantAccessibilityService.kt',
    language: 'kotlin',
    category: 'Kotlin',
    content: `package com.aiassistant.app.service

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AssistantAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AssistantAccessibilityService? = null
            private set

        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isServiceConnected.value = false
    }

    fun performGoHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performGoBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performOpenRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun performOpenNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun clickElementByText(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val matchingNodes = rootNode.findAccessibilityNodeInfosByText(text)
        matchingNodes?.firstOrNull()?.let { node ->
            return clickNodeOrParent(node)
        }
        return false
    }

    fun typeTextIntoField(targetHint: String?, textToType: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val focused = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val target = focused ?: rootNode.findAccessibilityNodeInfosByText(targetHint ?: "")?.firstOrNull()
        target?.let {
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType) }
            return it.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
        return false
    }

    fun scrollScreen(forward: Boolean): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val scrollable = findNode(rootNode) { it.isScrollable }
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return scrollable?.performAction(action) ?: false
    }

    fun extractCurrentScreenTexts(): List<String> {
        val rootNode = rootInActiveWindow ?: return emptyList()
        val list = mutableListOf<String>()
        fun traverse(n: AccessibilityNodeInfo?) {
            if (n == null) return
            n.text?.let { list.add(it.toString()) }
            for (i in 0 until n.childCount) traverse(n.getChild(i))
        }
        traverse(rootNode)
        return list
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo?): Boolean {
        var curr = node
        while (curr != null) {
            if (curr.isClickable) return curr.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            curr = curr.parent
        }
        return node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    private fun findNode(root: AccessibilityNodeInfo?, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (root == null) return null
        if (predicate(root)) return root
        for (i in 0 until root.childCount) {
            val res = findNode(root.getChild(i), predicate)
            if (res != null) return res
        }
        return null
    }
}`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    language: 'xml',
    category: 'Manifest & XML',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" tools:ignore="QueryAllPackagesPermission" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="com.android.alarm.permission.SET_ALARM" />
    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AiAssistant">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:windowSoftInputMode="adjustResize"
            android:theme="@style/Theme.AiAssistant">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".service.AssistantAccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

    </application>
</manifest>`
  },
  {
    path: 'app/build.gradle.kts',
    language: 'kotlin',
    category: 'Gradle Config',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.aiassistant.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aiassistant.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.kotlinx.coroutines.android)
}`
  }
];
