import React, { useState, useEffect, useRef } from 'react';
import {
  Smartphone,
  Code2,
  BookOpen,
  Sparkles,
  Download,
  CheckCircle2,
  FolderArchive
} from 'lucide-react';
import { AssistantStatus, CommandLog, SimulatedScreen } from './types';
import { PhoneSimulator } from './components/PhoneSimulator';
import { CodeExplorer } from './components/CodeExplorer';
import { BuildGuide } from './components/BuildGuide';
import { ANDROID_FILES } from './androidProjectFiles';

export default function App() {
  const [activeView, setActiveView] = useState<'simulator' | 'code' | 'guide'>('simulator');
  const [status, setStatus] = useState<AssistantStatus>('READY');
  const [recognizedText, setRecognizedText] = useState('');
  const [assistantResponse, setAssistantResponse] = useState('');
  const [activeScreen, setActiveScreen] = useState<SimulatedScreen>('HOME');
  const [volumeLevel, setVolumeLevel] = useState(70);
  const [isMuted, setIsMuted] = useState(false);
  const [micPermission, setMicPermission] = useState(true);
  const [accessibilityPermission, setAccessibilityPermission] = useState(true);
  const [voiceResponseEnabled, setVoiceResponseEnabled] = useState(true);
  const [selectedLanguage, setSelectedLanguage] = useState<'Hindi' | 'English' | 'Auto'>('Hindi');
  const [pendingConfirmationIntent, setPendingConfirmationIntent] = useState<string | null>(null);

  const [history, setHistory] = useState<CommandLog[]>([
    {
      id: 'init-1',
      timestamp: '12:28 PM',
      command: 'YouTube kholo',
      intent: 'OpenApp("YouTube")',
      actionExecuted: 'PackageManager.getLaunchIntentForPackage("com.google.android.youtube")',
      responseHindi: 'Bilkul, YouTube khol raha hoon.',
      success: true,
      isAccessibilityAction: false
    }
  ]);
  const [safetyPrompt, setSafetyPrompt] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);

  // Initialize Speech Recognition in Web Browser
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognizer = new SpeechRecognition();
      recognizer.continuous = false;
      recognizer.interimResults = false;
      recognizer.lang = 'hi-IN';

      recognizer.onstart = () => {
        setStatus('LISTENING');
      };

      recognizer.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        processUserCommand(text);
      };

      recognizer.onerror = () => {
        setStatus('ERROR');
        setAssistantResponse('माइक से आवाज़ नहीं पहचानी गई (No speech recognized).');
        setTimeout(() => setStatus('READY'), 2500);
      };

      recognizer.onend = () => {
        if (status === 'LISTENING') {
          setStatus('READY');
        }
      };

      recognitionRef.current = recognizer;
    }
  }, []);

  // Hindi TTS Voice Synthesizer
  const speakHindi = (text: string) => {
    if (!voiceResponseEnabled) {
      setStatus('READY');
      return;
    }

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = selectedLanguage === 'English' ? 'en-IN' : 'hi-IN';
      utterance.rate = 0.95;
      utterance.onstart = () => setStatus('SPEAKING');
      utterance.onend = () => setStatus('READY');
      utterance.onerror = () => setStatus('READY');
      window.speechSynthesis.speak(utterance);
    } else {
      setStatus('READY');
    }
  };

  const handleMicClick = () => {
    if (!micPermission) {
      setMicPermission(true);
      return;
    }

    if (status === 'LISTENING') {
      recognitionRef.current?.stop();
      setStatus('READY');
      return;
    }

    if (recognitionRef.current) {
      try {
        setRecognizedText('');
        setAssistantResponse('');
        recognitionRef.current.start();
        setStatus('LISTENING');
      } catch {
        // Fallback simulated voice listening if mic not allowed in current iframe
        setStatus('LISTENING');
        setTimeout(() => {
          processUserCommand('YouTube kholo');
        }, 1500);
      }
    } else {
      setStatus('LISTENING');
      setTimeout(() => {
        processUserCommand('YouTube kholo');
      }, 1500);
    }
  };

  // NLU & Execution Engine (Mirrors Native Kotlin NluEngine & AndroidActionExecutor)
  const processUserCommand = (rawCommand: string) => {
    setStatus('PROCESSING');
    setRecognizedText(rawCommand);
    const lower = rawCommand.toLowerCase();

    setTimeout(() => {
      // 1. Safety Check (Requirement 10: Sending messages, payments, deleting)
      if (
        lower.includes('message') ||
        lower.includes('sandesh') ||
        lower.includes('bhejo') ||
        (lower.includes('whatsapp') && lower.includes('amit'))
      ) {
        setStatus('READY');
        const prompt = 'Main Amit ko message bhejne wala hoon. Kya main continue karun?';
        setPendingConfirmationIntent(rawCommand);
        setSafetyPrompt(prompt);
        speakHindi(prompt);
        return;
      }

      setStatus('EXECUTING');

      // 2. Navigation Actions (Home, Back, Recents)
      if (lower.includes('home')) {
        if (!accessibilityPermission) {
          handlePermissionError('Home जाने');
          return;
        }
        setActiveScreen('HOME');
        logSuccess(rawCommand, 'GoHome', 'Accessibility Global Action: GLOBAL_ACTION_HOME', 'Home screen par aa gaye.', true);
        return;
      }

      if (lower.includes('back') || lower.includes('peeche') || lower.includes('wapas')) {
        if (!accessibilityPermission) {
          handlePermissionError('Back जाने');
          return;
        }
        setActiveScreen('HOME');
        logSuccess(rawCommand, 'GoBack', 'Accessibility Global Action: GLOBAL_ACTION_BACK', 'Wapas aa gaye.', true);
        return;
      }

      if (lower.includes('recent') || lower.includes('recents') || lower.includes('task')) {
        if (!accessibilityPermission) {
          handlePermissionError('Recent Apps खोलने');
          return;
        }
        setActiveScreen('RECENTS');
        logSuccess(rawCommand, 'OpenRecents', 'Accessibility Global Action: GLOBAL_ACTION_RECENTS', 'Recent apps khol diye gaye hain.', true);
        return;
      }

      // 3. Screen Scrolling (Scroll Up / Scroll Down)
      if (lower.includes('neeche scroll') || lower.includes('niche scroll') || lower.includes('scroll down')) {
        if (!accessibilityPermission) {
          handlePermissionError('स्क्रीन स्क्रॉल');
          return;
        }
        logSuccess(rawCommand, 'ScrollDown', 'AccessibilityNodeInfo.ACTION_SCROLL_FORWARD executed', 'Screen Neeche scroll kar di gayi hai.', true);
        return;
      }

      if (lower.includes('upar scroll') || lower.includes('scroll up')) {
        if (!accessibilityPermission) {
          handlePermissionError('स्क्रीन स्क्रॉल');
          return;
        }
        logSuccess(rawCommand, 'ScrollUp', 'AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD executed', 'Screen Upar scroll kar di gayi hai.', true);
        return;
      }

      // 4. Accessibility Click Screen Node
      if (
        lower.includes('search button') ||
        lower.includes('search par click') ||
        (lower.includes('search') && (lower.includes('dabao') || lower.includes('click')))
      ) {
        if (!accessibilityPermission) {
          handlePermissionError('स्क्रीन पर क्लिक');
          return;
        }
        setActiveScreen('SEARCH_RESULTS');
        logSuccess(
          rawCommand,
          'ClickText("Search")',
          'Accessibility Node matched: [Button text="Search", id="search_button"]. Triggered ACTION_CLICK.',
          'Screen par "Search" par click kar diya gaya hai.',
          true
        );
        return;
      }

      // 5. Read Screen Content
      if (lower.includes('screen read') || lower.includes('screen padho') || lower.includes('screen par kya hai')) {
        if (!accessibilityPermission) {
          handlePermissionError('स्क्रीन पढ़ना');
          return;
        }
        logSuccess(
          rawCommand,
          'ReadScreen',
          'Traversed rootInActiveWindow AccessibilityNodeInfo tree',
          'Screen par ye text dikh raha hai: Google Search, YouTube, Chrome, WhatsApp, Camera',
          true
        );
        return;
      }

      // 6. Volume Control
      if (lower.includes('volume kam') || lower.includes('awaz kam')) {
        setVolumeLevel((prev) => Math.max(0, prev - 20));
        setIsMuted(false);
        logSuccess(rawCommand, 'Volume(DECREASE)', 'AudioManager adjusted STREAM_MUSIC (-20%)', 'Volume kam kar di gayi hai.', false);
        return;
      }

      if (lower.includes('volume badhao') || lower.includes('awaz badhao')) {
        setVolumeLevel((prev) => Math.min(100, prev + 20));
        setIsMuted(false);
        logSuccess(rawCommand, 'Volume(INCREASE)', 'AudioManager adjusted STREAM_MUSIC (+20%)', 'Volume badha di gayi hai.', false);
        return;
      }

      // 7. Compound Command: "Chrome kholo aur Google search karo"
      if (lower.includes('chrome') && (lower.includes('search') || lower.includes('google'))) {
        setActiveScreen('CHROME');
        logSuccess(
          rawCommand,
          'MultiStep[OpenApp("Chrome"), WebSearch("Google")]',
          'Executed multi-step plan: launch Chrome and trigger search',
          'Bilkul, Chrome khol raha hoon aur Google par khoja ja raha hai.',
          false
        );
        return;
      }

      // 8. Launch Apps
      if (lower.includes('youtube')) {
        setActiveScreen('YOUTUBE');
        logSuccess(
          rawCommand,
          'OpenApp("YouTube")',
          'PackageManager.getLaunchIntentForPackage("com.google.android.youtube")',
          'Bilkul, YouTube khol raha hoon.',
          false
        );
        return;
      }

      if (lower.includes('whatsapp')) {
        setActiveScreen('WHATSAPP');
        logSuccess(
          rawCommand,
          'OpenApp("WhatsApp")',
          'PackageManager.getLaunchIntentForPackage("com.whatsapp")',
          'Bilkul, WhatsApp khol raha hoon.',
          false
        );
        return;
      }

      if (lower.includes('chrome')) {
        setActiveScreen('CHROME');
        logSuccess(
          rawCommand,
          'OpenApp("Chrome")',
          'PackageManager.getLaunchIntentForPackage("com.android.chrome")',
          'Bilkul, Chrome khol raha hoon.',
          false
        );
        return;
      }

      if (lower.includes('camera') || lower.includes('camara')) {
        setActiveScreen('CAMERA');
        logSuccess(
          rawCommand,
          'OpenApp("Camera")',
          'Intent(MediaStore.ACTION_IMAGE_CAPTURE)',
          'Bilkul, Camera khol raha hoon.',
          false
        );
        return;
      }

      if (lower.includes('settings') || lower.includes('setting')) {
        setActiveScreen('SETTINGS');
        logSuccess(
          rawCommand,
          'OpenSettings',
          'Intent(Settings.ACTION_SETTINGS)',
          'Bilkul, Settings khol raha hoon.',
          false
        );
        return;
      }

      // 9. Uninstalled App Handling (Requirement 7: "Say: 'Ye app aapke phone mein installed nahi hai.'")
      if (
        lower.includes('netflix') ||
        lower.includes('free fire kholo') ||
        lower.includes('snapchat') ||
        lower.includes('pubg')
      ) {
        logFailure(
          rawCommand,
          'OpenApp("Unknown")',
          'PackageManager returned null launch intent',
          'Ye app aapke phone mein installed nahi hai.'
        );
        return;
      }

      // 10. Web / Search fallback
      if (lower.includes('search') || lower.includes('khojo') || lower.includes('dhundo')) {
        setActiveScreen('SEARCH_RESULTS');
        logSuccess(
          rawCommand,
          'WebSearch("Free Fire")',
          'Triggered Intent.ACTION_WEB_SEARCH',
          'Google par "Free Fire" khoja ja raha hai.',
          false
        );
        return;
      }

      // 11. Generic Fallback
      logFailure(
        rawCommand,
        'Unknown',
        'NLU matched no executable intent',
        'Maaf kijiye, main ye samajh nahi paya. Aap bol sakte hain "YouTube kholo", "Home par jao", "Neeche scroll karo" aadi.'
      );
    }, 450);
  };

  const handlePermissionError = (actionName: string) => {
    const errorMsg = `${actionName} karne ke liye Accessibility Service chalu honi chahiye. Kripya Settings mein jakar AI Assistant service ko chalu karein.`;
    setAssistantResponse(errorMsg);
    setStatus('ERROR');
    speakHindi(errorMsg);

    const logItem: CommandLog = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      command: recognizedText,
      intent: 'AccessibilityAction',
      actionExecuted: 'Blocked: AssistantAccessibilityService not connected.',
      responseHindi: errorMsg,
      success: false,
      isAccessibilityAction: true
    };
    setHistory((prev) => [logItem, ...prev]);
  };

  const logSuccess = (
    command: string,
    intent: string,
    action: string,
    response: string,
    isAccess: boolean
  ) => {
    setAssistantResponse(response);
    speakHindi(response);

    const logItem: CommandLog = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      command,
      intent,
      actionExecuted: action,
      responseHindi: response,
      success: true,
      isAccessibilityAction: isAccess
    };
    setHistory((prev) => [logItem, ...prev]);
  };

  const logFailure = (command: string, intent: string, action: string, response: string) => {
    setAssistantResponse(response);
    setStatus('ERROR');
    speakHindi(response);

    const logItem: CommandLog = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      command,
      intent,
      actionExecuted: action,
      responseHindi: response,
      success: false,
      isAccessibilityAction: false
    };
    setHistory((prev) => [logItem, ...prev]);
  };

  const handleConfirmSafety = (allow: boolean) => {
    const cmd = pendingConfirmationIntent || recognizedText;
    setSafetyPrompt(null);
    setPendingConfirmationIntent(null);

    if (allow) {
      setActiveScreen('WHATSAPP');
      logSuccess(
        cmd,
        'SendMessage("Amit")',
        'User confirmed. Intent(Intent.ACTION_VIEW, whatsapp://send) triggered.',
        'Bilkul, WhatsApp khol raha hoon aur Amit ko message bhej raha hoon.',
        false
      );
    } else {
      setStatus('READY');
      const cancelMsg = 'Kriya radd kar di gayi hai (Action cancelled).';
      setAssistantResponse(cancelMsg);
      speakHindi(cancelMsg);

      const logItem: CommandLog = {
        id: Date.now().toString(),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        command: cmd,
        intent: 'SendMessage("Amit")',
        actionExecuted: 'Cancelled by user during SafetyManager confirmation.',
        responseHindi: cancelMsg,
        success: true,
        isAccessibilityAction: false
      };
      setHistory((prev) => [logItem, ...prev]);
    }
  };

  const handleNavAction = (action: 'BACK' | 'HOME' | 'RECENTS') => {
    if (action === 'HOME') {
      setActiveScreen('HOME');
    } else if (action === 'BACK') {
      setActiveScreen('HOME');
    } else if (action === 'RECENTS') {
      setActiveScreen('RECENTS');
    }
  };

  const handleScreenElementClick = (elementName: string) => {
    if (elementName === 'Search') {
      setActiveScreen('SEARCH_RESULTS');
    } else if (elementName === 'YouTube') {
      setActiveScreen('YOUTUBE');
    } else if (elementName === 'Chrome') {
      setActiveScreen('CHROME');
    } else if (elementName === 'WhatsApp') {
      setActiveScreen('WHATSAPP');
    } else if (elementName === 'Camera') {
      setActiveScreen('CAMERA');
    } else if (elementName === 'Settings') {
      setActiveScreen('SETTINGS');
    }
  };

  // Direct ZIP download of the complete native Android project
  const handleDownloadZip = async () => {
    const JSZip = (await import('jszip')).default;
    const zip = new JSZip();

    ANDROID_FILES.forEach((file) => {
      zip.file(file.path, file.content);
    });

    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'AI-Assistant-Native-Android.zip';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* App Header */}
      <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Sparkles className="w-5 h-5 text-slate-950 font-bold" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-white tracking-tight">AI Assistant</h1>
                <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 text-[10px] px-2 py-0.5 rounded-full font-semibold">
                  Native Android
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Voice-controlled Phone Automation (Hindi/Hinglish) • AccessibilityService • Jetpack Compose
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              className="bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow-md active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Download Android Studio ZIP</span>
              <span className="sm:hidden">ZIP</span>
            </button>
          </div>
        </div>

        {/* View switcher tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex gap-1 border-t border-slate-800/50">
          <button
            onClick={() => setActiveView('simulator')}
            className={`py-2.5 px-4 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeView === 'simulator'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Interactive Simulator</span>
          </button>

          <button
            onClick={() => setActiveView('code')}
            className={`py-2.5 px-4 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeView === 'code'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>Kotlin & Android Codebase ({ANDROID_FILES.length} files)</span>
          </button>

          <button
            onClick={() => setActiveView('guide')}
            className={`py-2.5 px-4 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeView === 'guide'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Setup & Architecture Guide</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {activeView === 'simulator' && (
          <PhoneSimulator
            status={status}
            recognizedText={recognizedText}
            assistantResponse={assistantResponse}
            activeScreen={activeScreen}
            volumeLevel={volumeLevel}
            isMuted={isMuted}
            micPermission={micPermission}
            accessibilityPermission={accessibilityPermission}
            history={history}
            safetyPrompt={safetyPrompt}
            voiceResponseEnabled={voiceResponseEnabled}
            selectedLanguage={selectedLanguage}
            onMicClick={handleMicClick}
            onSendCommandText={processUserCommand}
            onConfirmSafety={handleConfirmSafety}
            onToggleMicPermission={() => setMicPermission(!micPermission)}
            onToggleAccessibility={() => setAccessibilityPermission(!accessibilityPermission)}
            onToggleVoiceResponse={() => setVoiceResponseEnabled(!voiceResponseEnabled)}
            onSelectLanguage={(lang) => setSelectedLanguage(lang)}
            onNavAction={handleNavAction}
            onScreenElementClick={handleScreenElementClick}
            onDeleteHistoryItem={(id) => setHistory((prev) => prev.filter((item) => item.id !== id))}
            onClearHistory={() => setHistory([])}
            onNewConversation={() => {
              setRecognizedText('');
              setAssistantResponse('');
              setStatus('READY');
              setSafetyPrompt(null);
            }}
          />
        )}

        {activeView === 'code' && <CodeExplorer files={ANDROID_FILES} onDownloadZip={handleDownloadZip} />}

        {activeView === 'guide' && <BuildGuide onDownloadZip={handleDownloadZip} />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/60 py-4 px-6 text-center text-xs text-slate-500">
        AI Assistant • 100% Native Kotlin & Jetpack Compose Android Architecture • Compatible with Android Studio Ladybug/Koala & Gradle 8+
      </footer>
    </div>
  );
}
