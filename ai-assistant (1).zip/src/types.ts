export type AssistantStatus = 'READY' | 'IDLE' | 'LISTENING' | 'PROCESSING' | 'EXECUTING' | 'SPEAKING' | 'ERROR';

export type SimulatedScreen = 'HOME' | 'YOUTUBE' | 'CHROME' | 'WHATSAPP' | 'CAMERA' | 'SETTINGS' | 'RECENTS' | 'SEARCH_RESULTS';

export interface CommandLog {
  id: string;
  timestamp: string;
  command: string;
  intent: string;
  actionExecuted: string;
  responseHindi: string;
  success: boolean;
  isAccessibilityAction: boolean;
}

export interface AndroidFile {
  path: string;
  language: string;
  category: 'Kotlin' | 'Manifest & XML' | 'Gradle Config' | 'Resources';
  content: string;
}

export interface SimulatorSettings {
  voiceResponse: boolean;
  language: 'Hindi' | 'English' | 'Auto';
  aiProviderConfigured: boolean;
  aiApiKey: string;
}
